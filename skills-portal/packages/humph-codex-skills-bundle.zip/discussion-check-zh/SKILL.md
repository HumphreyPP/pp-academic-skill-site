---
name: discussion-check-zh
description: 用于检查 academic discussion 段落或完整 discussion section 是否真正构成理论对话、论证链是否成立、表达是否清晰。适用于判断 discussion 是否只是 results 的 prose version，识别每段概念推进，检查 claim/reason/evidence/warrant 论证逻辑，评估文献对话、异议回应、限定语、段落结构和英文表达，并给出修改意见与改写稿。
---

# Discussion Check ZH

## 这个 Skill 的总目标

使用这个 skill 时，把 discussion 当成一个“理论论证系统”来检查，而不是只看语言是否学术、句子是否流畅。

通用性优先：本 skill 不绑定任何具体研究主题。正文中的算法治理、AI advice、公民评价、问责、代表性等表达只作为领域示例；给团队其他成员使用时，先抽象为更通用的理论对象、机制、边界条件、评价对象和文献对话，再根据用户自己的研究领域替换术语。

一个合格的 discussion 段落至少要同时完成三件事：

1. 解释一个发现为什么重要。
2. 把这个发现转化为一个理论命题。
3. 用清楚的论证链说明读者为什么应该接受这个命题。

最高优先级规则：每一段 discussion 至少要有一个清楚的概念推进。

如果一段文字只是在复述结果、报告 interaction、罗列文献，或者堆叠某个领域的抽象词，但没有改变读者对某个理论对象、概念、机制或边界条件的理解，就不能算合格的理论对话段落。

## 使用来源

这个 skill 的规则综合三套写作判断：

- 原有 discussion check SOP：强调每段必须有概念推进，并把概念推进分为理论对象、概念内涵、机制、边界条件、研究版图五类。
- Booth et al., The Craft of Research, 5th ed.：强调 research argument 由 claim、reason、evidence、warrant，以及 acknowledgment/response 构成。
- Wallwork, English for Writing Research Papers, 2023：强调 discussion 要解释结果的意义、与文献对话、处理不同解释和限制，并用清晰、简洁、逻辑连续的段落表达。

不要在回答里长篇引用这些书。使用它们转化出的检查规则即可。

## 导师式 Discussion 推进法

检查用户的 discussion 时，优先使用以下“导师式推进”标准。它们来自用户导师对论文 discussion 的修改反馈，重点不是把句子写得更高级，而是让段落真正形成理论推进。

### 1. 把结果改写成理论命题

不要只复述 `we found X`。强 discussion 要把结果改写为一个关于概念、机制或研究对象的判断。

- 弱：Group A evaluates condition X more positively than condition Y.
- 强：the meaning of X depends on how actors interpret the discretion, constraint, or responsibility that X makes visible.

领域示例可以更具体，但不要把它当成默认主题：如果研究对象是算法治理，可以写成 `the fairness advantage of human involvement depends on how officials use the discretion that human involvement preserves`。

检查时问：

- 这段有没有把 empirical finding 转化成 theoretical claim？
- 这个 claim 是否改变了读者对某个概念的理解？
- 是否避免把贡献写成“我们加入了一个变量”？

### 2. 给文献差异找一个比较轴

当用户比较本研究和已有文献时，不要只写 `our findings differ from prior work`。必须指出差异发生在哪个轴上。

常见比较轴包括：

- information availability
- outcome feedback
- decision stage
- decision-maker type
- institutional context
- form of discretion
- evaluation target

检查时问：

- 与前人不同的核心条件是什么？
- 这个条件为什么会改变机制或评价？
- 这是否构成 boundary condition、refinement 或 reconciliation？

### 3. 把机制写成链条，而不是解释堆叠

机制段落要让读者看见连续推理：`cue -> citizen inference -> evaluative consequence`。

通用链条例如：

- A visible cue gives readers or participants a reference point.
- A departure from that reference point invites an attribution.
- The attribution changes how the action, actor, or institution is evaluated.
- This evaluation affects the theoretical outcome of interest.

检查时问：

- 每一句是否推动下一步推理？
- 是否存在多个近义解释句反复说同一件事？
- 是否说明了为什么这个 cue 会引发这种 inference？

### 4. 让每篇文献承担明确角色

文献不能只是被放进括号里。每篇关键文献都应该在论证中承担一个角色。

常见角色包括：

- baseline claim：说明既有研究通常怎么看。
- mechanism support：支持某个解释机制。
- contrast case：提供一个看似相反的发现。
- boundary condition：帮助说明本研究适用于什么条件。
- alternative explanation：帮助回应可能的异议。

检查时问：

- 这篇文献在本段中具体支撑哪一句？
- 它和本研究是 confirm、extend、refine、challenge、reconcile，还是 set a boundary condition？
- 如果删掉这篇文献，本段的理论论证会不会受损？如果不会，说明引用可能只是装饰。

### 5. 强贡献，谨慎机制

贡献句可以相对有力，但未经直接检验的机制必须谨慎。

可用于贡献句：

- we show
- we refine
- this study advances
- this finding extends

可用于机制句：

- may
- suggests
- appears to
- is consistent with
- can be interpreted as

检查时问：

- 结果是否被写成了机制的直接证明？
- suggestive evidence 是否被写成 definitive proof？
- 强动词是否和证据强度匹配？

## 一、Discussion 的构成体系

检查 discussion 时，先判断文本在 section 层面是不是具备 discussion 的基本功能。

### 1. Findings To Meaning

discussion 不是重复发现，而是说明发现意味着什么。

合格表现：

- 先给出发现的理论含义，再用结果支撑。
- 解释结果如何改变、细化或限制已有理解。
- 说明结果与研究问题、理论问题或知识缺口的关系。

不合格表现：

- 结果句连续出现，但没有 interpretation。
- 段落中心是显著性、方向、interaction、pairwise comparison。
- 结尾只写 “this result is important” 但没有说明 important 在哪里。

### 2. Literature Dialogue

discussion 必须让读者知道你在和哪条文献线对话。

合格表现：

- 点明既有研究通常如何理解这个问题。
- 说明你的发现是 confirm、extend、refine、challenge，还是 set a boundary condition。
- 明确说出你的研究与某篇或某类文献的关系。

不合格表现：

- 只是把文献塞进段落。
- 只写 “consistent with previous research” 或 “different from previous research”。
- 没有解释为什么相同或不同在理论上重要。

### 3. Interpretation And Alternative Explanation

discussion 要解释你的 interpretation，也要让读者看到你知道可能存在其他解释。

合格表现：

- 清楚区分 evidence、interpretation、speculation。
- 对可能的替代解释进行承认和回应。
- 当证据不足时使用合适的限定语，例如 suggest、may、appears to、is consistent with。

不合格表现：

- 把 suggestive evidence 写成 definitive proof。
- 完全回避不支持你解释的文献或结果。
- 只承认 limitation，但不说明它如何影响 claim 的范围。

### 4. Limitation To Contribution

discussion 可以讲 limitation，但不能让 limitation 成为最后的落点。

合格表现：

- 承认限制。
- 说明这些限制如何影响 claim 的适用范围。
- 最后回到理论贡献、边界条件、future research 或更一般的 implication。

不合格表现：

- 只说 “sample size is small” 但不说明这限制了什么推断。
- 在结尾停留于 limitation，导致段落没有建设性收束。

### 5. Section-Level Progression

完整 discussion 不应是一串互不相干的段落，而应形成概念推进顺序。

优先顺序通常是：

1. 回答最核心的研究问题。
2. 解释最重要的理论贡献。
3. 与关键文献对话。
4. 说明机制或边界条件。
5. 处理替代解释、限制和非预期结果。
6. 推出更一般的理论或实践含义。

如果用户给出完整 discussion，要检查段落之间是否重复、跳跃、缺桥接句，或把 practical implication 放得太早。

## 二、每段必须有概念推进

概念推进不是把句子写得更抽象，而是让读者必须重新理解某个理论对象、概念、机制或边界。

每段至少满足下面五类之一。

### 1. 推进理论对象

把问题从 A 改写成 B。

合格句型：

- This shifts the question from X to Y.
- Rather than treating X as..., this study shows that...
- Our contribution is not simply to add a variable, but to recast X as Y.

检查问题：

- 原来的理论对象是什么？
- 新的理论对象是什么？
- 为什么这个改写有必要？
- findings 如何支持这个改写？

### 2. 推进概念内涵

说明某个概念不只是原来那样，而包含新的维度或含义。

合格句型：

- X is not only A, but also B.
- X should be understood as A rather than merely B.
- This adds an interpretive / institutional / relational dimension to X.

检查问题：

- 旧理解是什么？
- 新增维度是什么？
- 新维度如何运作？

### 3. 推进机制

说明真正起作用的是某种解释过程、意义赋予过程、线索读取过程或推断过程。

合格句型：

- X matters because it changes how relevant actors, audiences, or readers interpret Y.
- X works by making Y readable as Z.
- Actors use A as a cue for judging B.

检查问题：

- 被解释的行为或对象是什么？
- 哪个 cue 改变了 interpretation？
- 为什么这种 interpretation 在该情境下更可能发生？

### 4. 推进边界条件

说明理论命题在什么条件下成立，以及为什么。

合格句型：

- This identifies a boundary condition: the logic holds when...
- The mechanism becomes consequential under conditions of...
- This account applies especially when...

检查问题：

- 条件是什么？
- 这个条件改变了什么推理基础？
- 这是不是把别人的发现条件化，而不是简单说 “我们和别人不同”？

### 5. 扩展研究版图

把讨论从一个对象、层级或领域推进到另一个更大的问题。

合格句型：

- This moves the debate from X to Y.
- This extends the literature beyond X toward Y.
- More broadly, the findings reposition X as part of Y.

检查问题：

- 原研究版图是什么？
- 新研究版图是什么？
- 前文是否已经提供足够支撑，避免无根据拔高？

## 三、文献与理论对话比较体系

检查 discussion 时，不能只问“有没有引用文献”，而要问“文献在本段论证中扮演什么角色”。文献不是装饰，也不是背景噪音；它应该帮助作者定位问题、建立理论张力、提供支持、形成比较、回应异议，或展示研究如何改变已有理解。

### 1. 文献对话的最低标准

每次提到文献，都必须能回答四个问题：

1. 这个文献或理论主张说了什么？
2. 它和本文发现有什么关系？
3. 这种关系属于 confirm、extend、refine、challenge、boundary-setting、reconcile，还是 redirect？
4. 这种关系为什么会产生理论意义？

如果一段 discussion 只写 “consistent with prior research” 或 “different from previous studies”，但没有说明一致或不同意味着什么，这不是文献对话，只是文献并列。

### 2. 七种文献-理论比较关系

诊断文献对话时，优先使用下面七类关系。每段不一定都要包含文献比较，但只要出现文献，就必须能归入至少一种关系。

#### Confirm

含义：本文发现支持既有理论或文献判断。

合格写法必须说明：本文支持的是既有文献的哪个具体 claim、mechanism 或 boundary，而不是笼统说 “consistent with”。

弱写法：

- This is consistent with prior studies.

强写法：

- This pattern supports prior work's claim that actors use visible cues to infer institutional meaning, but it specifies which cue becomes salient under the study's focal condition.

#### Extend

含义：既有理论在原情境中成立，本文把它扩展到新对象、新情境、新群体或新层级。

检查问题：

- 原理论适用于哪里？
- 本文扩展到哪里？
- 为什么这个扩展不是简单换场景，而是理论上有新信息？

#### Refine

含义：既有理论大体正确，但本文让它更精细，比如区分维度、机制、条件或对象。

检查问题：

- prior work 的说法哪里太粗？
- 本文把它拆成了哪些更细的部分？
- 这种细化如何改变读者理解？

#### Challenge

含义：本文发现与既有理论或文献不一致，并对其核心假设提出质疑。

检查问题：

- 你挑战的是结果、机制、概念定义，还是适用范围？
- 是否公平呈现了被挑战文献？
- 是否避免把别人的研究写成 straw man？

#### Boundary-Setting

含义：既有理论不是错，而是在某些条件下成立；本文指出它的适用边界。

强写法通常是：

- Prior work explains X under condition A; our findings suggest that under condition B, the logic changes because...

这比简单说 “our context is different” 更有理论价值。

#### Reconcile

含义：本文帮助解释为什么两组看似矛盾的文献都可能成立。

检查问题：

- 哪两类文献或发现存在 tension？
- 本文用什么机制或边界条件调和它们？
- 调和后产生了什么更高层次的理论命题？

#### Redirect

含义：本文把文献关注点从一个理论对象转向另一个理论对象。

例子：

- from system-level explanations to actor-level practices
- from technical error or bias to how people interpret the handling of tools, rules, or classifications

这类关系通常对应“推进理论对象”或“扩展研究版图”。

### 3. Creative Agreement 与 Creative Disagreement

读文献和写 discussion 时，不要只寻找“支持我”或“反对我”的文献。要检查作者是否把文献转化为创造性对话。

#### Creative Agreement

当本文同意既有文献时，仍要推进一步。

可用方式：

- 提供更强或更新的证据。
- 证明既有文献只是推测但尚未证明的点。
- 把既有主张应用到新情境。
- 说明既有机制在新的对象上也成立。

诊断句：

- 这段目前只是 agreement，还没有 creative agreement；它需要说明本文新增了什么证据、情境、机制或边界。

#### Creative Disagreement

当本文不同意既有文献时，不要只是说 “we differ”。要说明分歧类型。

常见分歧类型：

- Definition / classification：对概念类别或定义不同意。
- Part-whole relation：对某个因素是否属于机制的一部分不同意。
- Development：对某个现象如何演化或形成不同意。
- Cause and effect：对因果关系或机制不同意。
- Perspective：用新的理论视角重新解释同一现象。

诊断句：

- 这段已经指出差异，但还没有说明差异属于哪一种理论分歧，因此 theoretical stakes 不够清楚。

### 4. 文献角色标注

检查 discussion 时，给每个被引用文献标注它的角色。

常见角色包括：

- Background：提供问题背景。
- Target：作为本文要 refine、challenge 或 boundary-setting 的对象。
- Ally：支持本文 claim。
- Contrast：形成对比或 tension。
- Evidence Source：提供本文 reason 的外部证据。
- Warrant Source：提供 reason 到 claim 的理论桥。
- Method / Reasoning Model：提供论证方式或分析模式。

如果一个引用没有角色，建议删除、移动到 literature review，或明确它在段落中的作用。

### 5. 文献比较的五步结构

当一段 discussion 需要比较本文与既有研究时，优先使用这个顺序：

1. 先概括本文发现或理论 claim。
2. 再说明某篇或某类文献的相关 claim。
3. 明确标注关系：confirm / extend / refine / challenge / boundary-setting / reconcile / redirect。
4. 解释为什么这种关系会改变理论理解。
5. 收束成更一般的理论命题。

这套结构来自一个很简单的判断：读者不应该自己猜“你为什么提这篇文献”。作者必须让文献与本文发现之间的关系变得 100% 清楚。

### 6. 文献批评的可信度规则

批评文献时，必须建设性、准确、克制。

合格批评：

- 公平概括对方观点。
- 指出对方的假设、证据、情境或范围限制。
- 说明本文如何补充、测试、细化或限制它。
- 不暗示对方“错了”，除非本文 evidence 足以支持这种强 claim。

不合格批评：

- 只说 prior work overlooks X，但没有说明为什么 X 重要。
- 把文献写成过于简单的对立面。
- 用一个局部结果推翻整个理论传统。
- 只引用支持自己的研究，回避不一致文献。

### 7. 不一致文献与替代解释

如果存在不支持本文发现的文献，discussion 应该处理它。

处理方式：

- 说明不一致是否来自不同情境、样本、测量、理论对象或机制。
- 如果无法解释，承认它是 limitation 或 future research 的来源。
- 不要把不一致文献藏起来；这会削弱可信度。

可用句型：

- While prior work suggests X, our findings indicate that this logic may depend on Y.
- This difference does not necessarily contradict prior work; instead, it suggests a boundary condition related to Z.
- An alternative interpretation is X, but this account is less consistent with the observed concentration of effects under Y.

### 8. 文献-理论对话的常见失败模式

#### Citation Dumping

症状：一句话后面堆多个引用，但没有解释文献之间的关系，也没有说明它们如何支持本段 claim。

处理：要求作者拆出关键文献角色，保留真正进入论证链的文献。

#### Same/Different Trap

症状：只说本文和过去一样或不一样。

处理：追问 “so what?”，要求说明一致或差异产生什么理论后果。

#### Literature Review Regression

症状：discussion 段落退回成 literature review，介绍了很多文献，却没有回到本文 findings。

处理：把本文 claim 放回段首或段尾，让文献服务于本文理论推进。

#### Unsupported Challenge

症状：用 suggestive 或局部 findings 挑战很大的理论命题。

处理：降低 claim 强度，改成 refine、boundary-setting 或 raise questions about。

#### Missing Warrant Source

症状：引用了文献，但没有说明该文献提供的是 evidence 还是 warrant。

处理：明确该文献是在支持事实判断、机制判断，还是推理原则。

## 四、CREW 论证链检查

用 Booth 式 argument 逻辑检查每段是否真正站得住。CREW 指 Claim、Reason、Evidence、Warrant。

每段 discussion 至少要能标出这四个成分。如果某个成分缺失，要指出论证断在哪里。

### C = Claim

Claim 是这段要读者接受的理论主张。

在 discussion 里，claim 不应只是经验发现，而应是 findings 的理论含义。

弱 claim：

- We found a significant interaction.
- Accountability orientation affects perceived fairness.

强 claim：

- The focal institutional orientation functions as an interpretive lens through which audiences judge departures from a visible rule, recommendation, or expectation.

检查 claim 时问：

- 这段到底要我相信什么？
- 这个 claim 是否 specific？
- 这个 claim 是否 significant，也就是会改变读者对理论问题的理解？
- 这个 claim 是否 contestable，而不是空泛常识？
- 这个 claim 是否被适当限定，没有超出证据？

### R = Reason

Reason 是为什么读者应该接受 claim。

Reason 通常是一个解释性判断，而不是原始数据本身。

弱 reason：

- Because the result is significant.

强 reason：

- Because the pattern appears only when the contextual condition makes a particular concern plausible, suggesting that audiences interpret the focal action as revealing motive, competence, constraint, or responsibility.

检查 reason 时问：

- reason 是否直接支持 claim？
- reason 是否只是重复 claim？
- reason 是否按照清楚顺序展开？
- 如果有多个 reasons，它们之间是否有逻辑顺序，而不是并列堆放？

### E = Evidence

Evidence 是支撑 reason 的材料。

在 discussion 里，evidence 可以是结果模式、对比、稳健性分析、文献证据、机制证据或案例证据。但 evidence 不能自己说话，必须被解释。

弱 evidence 使用方式：

- Pairwise comparisons show...
- The coefficient is significant...

强 evidence 使用方式：

- This interpretation is supported by the fact that the difference is concentrated in the condition where suspicion should be strongest.

检查 evidence 时问：

- evidence 支撑的是 reason，还是直接被拿来当 claim？
- evidence 是否足够、代表性合理、来源可信？
- evidence 是否被解释清楚，让读者知道该看见什么？
- 是否有 cherry-picking 风险，只讲支持自己的结果？
- 是否引入了 Results 部分没有出现的新发现？如有，提醒用户不应在 discussion 首次引入新结果。

### W = Warrant

Warrant 是连接 reason 和 claim 的一般推理原则。它回答 “How does that follow?”。

在 discussion 中，warrant 常常是隐含的，但当读者可能不理解或挑战推理时，必须显性写出来。

例子：

- Claim: an institutional safeguard buffers negative evaluations.
- Reason: evaluations are more favorable when the safeguard is visible under the condition that otherwise raises suspicion.
- Warrant: when audiences suspect misuse, visible monitoring and enforceable consequences make the action less likely to be read as self-serving or arbitrary.

检查 warrant 时问：

- 从 reason 到 claim 的桥在哪里？
- 这个桥是否合理？
- 这个桥是否限定得足够，不是过度普遍化？
- 是否存在 competing warrant？例如同一 evidence 也可以支持另一种解释？
- 这个 warrant 是否符合该研究领域的理论习惯？

### Acknowledgment And Response

CREW 之外，还要检查 acknowledgment/response。

合格 discussion 通常要承认并回应：

- 替代解释
- 不一致文献
- 非预期结果
- 方法限制
- 证据只能支持的范围

检查问题：

- 这段有没有承认读者最可能提出的反问？
- 有没有回应这个反问，而不是只承认后放在那里？
- 有没有用限定语保持可信度？

## 五、Discussion 段落的标准结构

每段 discussion 优先使用下面结构。不是每段都必须机械完整，但缺哪个环节，就要说明风险。

### Step 1：理论对象句

第一句尽量说明本段要推进什么理论对象或概念。

不要优先写：

- Our results show...
- H2 is supported...

优先写：

- This study advances...
- Existing research has treated X as..., but our findings suggest...
- This paragraph refines the idea that...

### Step 2：既有研究定位

用一到两句说明 prior work 怎么理解这个问题。

检查重点：是否给读者建立了对话对象。

### Step 3：不足或张力

指出 prior work 解释不了什么，或者在哪个条件下还不清楚。

这里写的是 insufficiency，不只是 difference。

### Step 4：概念推进句

明确写出本段核心理论推进。

这一句应能被归入五类概念推进之一。

### Step 5：CREW 支撑

用 reason、evidence、warrant 支撑概念推进。

顺序通常是：claim -> reason -> evidence -> warrant / implication。

如果段落先给 evidence，再慢慢推出 claim，也可以接受，但最后必须让 claim 清楚。

### Step 6：文献对话或异议回应

如果本段涉及文献比较，要明确：

- 你的发现 confirm 什么？
- refine 什么？
- challenge 什么？
- 与不一致结果如何共存？
- 该文献在本段中是 target、ally、contrast、evidence source，还是 warrant source？

### Step 7：理论收束

最后一句要回到更一般的理论含义，不能停在结果。

## 六、表达水平检查

使用 Wallwork 式 clarity 标准检查 discussion 的英文表达。

### 1. 段落长度和焦点

规则：一个段落只服务一个中心推进。

需要拆段的信号：

- 从一个结果转到另一个结果。
- 从自己的发现转到他人文献。
- 从文献对话转到 limitation。
- 从解释结果转到 implication。
- 段落超过 4 到 6 个实质句且出现新焦点。

### 2. 句间逻辑链

每个句子都应该接住前一句，并向下一步推进。

检查问题：

- 句子是否从 general 到 specific，或从 known 到 new？
- 新信息是否突然跳入，没有桥接？
- 关键术语是否稳定重复，而不是为了避免重复乱换同义词？

### 3. Own Findings vs Others' Findings

discussion 最容易乱的地方是读者不知道一句话是在讲你的结果、别人的结果，还是一般理论。

必须检查：

- 是否用 our findings / this study / prior work / these studies 等清楚标记来源。
- 代词 they / this / these / the former / the latter 是否可能造成歧义。
- 文献比较中是否清楚说明关系，而不是让读者自己推断。

### 4. Concision

discussion 要尽量压缩重复报告性表达。

优先删除或压缩：

- it has been suggested that
- it has been reported that
- the results of X showed that
- interestingly / importantly 的空泛使用
- 重复的 “our results show / pairwise comparisons show”

但不要删除必要的限定语。简洁不能以过度确定为代价。

### 5. Precision And Hedging

当 evidence 只是 suggestive，不能写成 definitive。

常用限定语功能：

- suggest：证据支持某解释，但不是最终证明。
- may / might：提出可能机制或边界。
- appears to / seems to：承认仍有未检验情况。
- is consistent with：说明 evidence 与解释相容，而不是证明唯一解释。

检查问题：

- claim 的力度是否超过 evidence？
- 是否把相关关系写成因果关系？
- 是否把局部条件写成普遍规律？

### 6. Sentence-Level Clarity

检查英文句子是否让读者顺着读，而不是反复回头。

重点检查：

- 主语和动词是否靠得太远。
- 一个句子是否塞入太多想法。
- which / this / these / it 指代是否清楚。
- 比较句是否明确说明和谁比较、比较什么。
- long noun phrase 是否遮住了核心动作。

修改原则：优先用清楚的 subject + verb 结构，让理论动作变成句子的主动作。

## 七、评分体系

当用户要求 detailed check 时，使用 100 分评价体系。

### 1. Discussion 构成，20 分

检查：是否解释意义、连接研究问题、与文献对话、处理限制和 implication。

### 2. 理论对话与概念推进，25 分

检查：是否有明确理论对象、对话对象、prior work insufficiency、至少一个概念推进、理论收束。

如果某段没有概念推进，本项最高只能给 10 分。

### 3. CREW 论证链，25 分

检查：claim 是否 specific/significant/contestable/qualified，reason 是否直接支持 claim，evidence 是否支撑 reason，warrant 是否连接 reason 和 claim，是否回应异议。

### 4. 文献与理论对话比较，15 分

检查：是否明确文献角色，是否说明本文与既有理论的关系属于 confirm、extend、refine、challenge、boundary-setting、reconcile 或 redirect，是否处理不一致文献，批评是否建设性，是否避免 citation dumping、same/different trap 和 cherry-picking。

### 5. 表达清晰度，15 分

检查：段落焦点、句间逻辑、简洁性、指代清楚、限定语准确、英文表达是否顺。

评分解释：

- 90 到 100：强 discussion，可做精修。
- 75 到 89：基本合格，但需要增强某些理论或论证环节。
- 60 到 74：有 discussion 雏形，但仍偏结果说明。
- 60 以下：需要重构，不建议只做语言润色。

## 八、输出格式

默认输出六个板块。

### A. 总评

用两三句话判断：这段是否构成 discussion，主要问题在理论推进、CREW 论证链，还是表达清晰度。

### B. 段落功能与概念推进诊断

说明：

- 本段承担什么 discussion 功能。
- 有没有概念推进。
- 属于哪一类概念推进。
- 是否满足“每段至少一个概念推进”的硬标准。

### C. 文献与理论对话比较

当段落涉及文献时，标出：

- 对话对象：本段在和哪条文献或理论说话。
- 文献角色：target / ally / contrast / evidence source / warrant source / reasoning model。
- 比较关系：confirm / extend / refine / challenge / boundary-setting / reconcile / redirect。
- 问题：是否只是 citation dumping 或 same/different trap。
- 修复：如何把文献关系改成理论推进。

### D. CREW 论证链检查

用简短列表标出：

- Claim：本段核心主张是什么。
- Reason：支持它的理由是什么。
- Evidence：证据是什么。
- Warrant：reason 如何通向 claim。
- Gap：哪一环缺失或不够清楚。

### E. 表达与结构问题

指出段落组织、句间逻辑、过度结果化、指代、限定语、冗余表达等问题。

### F. 修改意见 + 为什么这么改

每条建议都包含：

- Problem:
- Why it matters:
- Revision:

### G. 修改后的文本

给出可直接使用的修改版。

改写时保留用户原本的 substantive claim，除非原 claim 明显超出 evidence。若 evidence 不足，要把 claim 改得更有边界。

## 九、常见诊断句

### 不合格

- 这段目前更像 results 的 prose version，而不是完整的理论对话单元。
- 这段有理论词汇，但还没有概念推进。
- 这段有 claim，但 reason 和 warrant 没有连上，所以论证链断在中间。
- 这段提到了文献，但没有说明文献和本文发现之间的理论关系，因此还停留在 citation dumping。

### 部分合格

- 这段已经有概念推进雏形，但 claim 还不够 specific。
- 这段 evidence 足够，但 warrant 没有显性化，读者可能看不出为什么该结果支持该理论命题。
- 这段已有文献对话，但还没有说明你的研究是 confirm、refine、challenge 还是 boundary-setting。
- 这段已经有 same/different 比较，但还需要说明差异背后的机制、边界条件或理论对象变化。

### 合格

- 这段已经完成从 findings 到 theory 的转化。
- 这段不仅解释了结果，还说明了该结果如何改变我们对概念或机制的理解。
- 这段的 claim、reason、evidence 和 warrant 基本连贯，具备可信的 theory dialogue。
- 这段清楚说明了本文与既有文献的关系，并把这种关系转化成了理论推进。

## 十、改写句型库

### Claim 句

- This study advances [literature] by showing that [concept] is better understood as [new meaning].
- Existing research has largely treated [X] as [old view], but our findings suggest that [new view].
- Our contribution is not simply to show [finding], but to recast [object] as [new object].

### Reason 句

- This matters because [condition] changes how [actor] interprets [object].
- The key reason is that [cue] makes [action] more readily readable as [interpretation].
- This interpretation follows from the fact that [pattern] appears precisely when [theoretical condition] is most salient.

### Evidence 句

- This interpretation is supported by the observed pattern that [finding].
- The evidence is consistent with this account because [finding] is concentrated in [condition].
- Rather than showing a uniform effect, the results indicate that [effect] depends on [boundary condition].

### Warrant 句

- The underlying logic is that when [general circumstance], [general consequence].
- This inference rests on the assumption that [cue] is read by [audience/actor] as [meaning].
- This connection is plausible because [field/theory] treats [reason] as evidence of [claim].

### Acknowledgment / Response 句

- Although this evidence is suggestive rather than definitive, it is consistent with [interpretation].
- An alternative interpretation is that [alternative], but this account is less consistent with [pattern].
- This does not imply that [overclaim]; rather, it suggests that [bounded claim].

### Literature Dialogue 句

- Prior work has shown [X], but our findings refine this claim by showing that [Y].
- Rather than contradicting [literature], this pattern identifies a boundary condition: [condition].
- This extends [theory] from [original context] to [new context], where [why extension matters].
- This difference is theoretically important because it suggests that [mechanism / concept / boundary].
- These findings reconcile two strands of research by showing that [A] holds when [condition 1], whereas [B] holds when [condition 2].
- The relevant point is not simply that our findings differ from [study], but that the difference shifts attention from [old object] to [new object].

### Theoretical Closure 句

- Taken together, this suggests that [concept] should be understood as [generalized claim].
- More broadly, this identifies a boundary condition for [theory].
- In this sense, the findings move the debate from [old focus] to [new focus].

## 十一、最终检查清单

输出前必须确认：

- 每段都被单独诊断。
- 每段都识别了 discussion 功能。
- 每段都判断了是否有概念推进。
- 每段涉及文献时，都标明了文献角色和比较关系。
- 每段都检查了 claim、reason、evidence、warrant。
- 每段都指出了至少一个具体表达或结构问题。
- 修改建议解释了为什么这样改。
- 改写版本至少包含一个概念推进。
- 改写版本没有把 suggestive evidence 写成 definitive proof。
- 改写版本没有引入用户没有提供的新发现或新引用。
 
## 十二、机制化理论对话工作法

当用户觉得某段 discussion “只是在讲发现”“理论层次不够”“对话不带劲”时，必须从 wording 修改转入机制化理论对话。不要只替换连接词或堆文献，而要把发现改写成对既有理论的条件化、机制化或概念推进。

### 1. 先拆准原始理论命题

先问并回答：被对话文献的核心理论命题是什么？

- 它解释的是哪个理论对象：身份关系、制度线索、组织结构、技术工具、专业判断、资源分配、文本类别、互动过程，还是评价结果？
- 它的机制是什么：谁受益、谁决策、行动如何被约束、受众如何归因、组织如何发出信号、知识如何被分类，还是实践如何改变关系？
- 它默认的情境、对象和评价目标是什么？

输出时不要只说“某文献支持我们的机制”。要明确写出：

- `Prior study: X -> Y because Z.`
- `Our study: X still matters, but only/especially when W.`

### 2. 用“反推回原文献”的方式检验理论推进

一个真正有推进的 discussion 不仅能解释自己的结果，还能说明：如果把本研究的新条件放回被对话文献，原来的结论会如何变化。

必须尝试回答：

- 如果把我们的 moderator / mechanism / context 加回那篇文献，它的结果会增强、减弱、反转，还是只在某些条件下出现？
- 这个变化说明我们是补充、限定、机制化、还是重新定位了原理论？
- 如果无法说明原文献结果会有什么预期变化，通常说明现在只是“结果并列”，不是理论对话。

可用表达：

- `This suggests that [prior mechanism] is not driven only by [old factor], but also depends on [new condition].`
- `If this logic were applied to [prior study], the fairness penalty should be weaker when [condition A] and stronger when [condition B].`
- `Thus, our findings qualify [prior account] by showing when its core logic becomes more or less consequential.`

### 3. 从“结果差异”上升到“机制差异”

不要停在：

- `Our findings differ from X.`
- `Our study extends X to a new context.`
- `This is consistent with X.`

要继续追问：

- 差异来自 information availability、visible action、identity relation、institutional constraint、reference point、classification rule、resource dependency，还是 attributional context?
- 读者理解的理论对象是否被改变了？
- 原来被看成结果的东西，是否其实是机制的一部分？

优先使用这类理论句：

- `The contribution is not simply that [effect appears in new context], but that [concept] becomes conditional on [mechanism].`
- `This moves the explanation from [old account] to [new account].`
- `This reframes [concept] as not only [old meaning], but also [new meaning].`

### 4. 建立 cue -> attribution -> evaluation 的链条

讨论评价、合法性、公平感知、信任、问责、代表性、合作、接受度或其他 judgment outcome 时，必须检查是否存在清楚的三步链条：

- `Cue`: 受众、行动者或读者看到了什么线索？如规则变化、信息呈现、分类标签、身份关系、专业判断、监督、制裁、结果正确性。算法治理研究中的 AI rejection 只是其中一种例子。
- `Attribution`: 他们据此如何归因？如 personal discretion、favoritism、bounded judgment、correction、arbitrariness、competence、care、strategic behavior。
- `Evaluation`: 这种归因如何影响 fairness / legitimacy / trust / blame / compliance / support / credibility?

如果句子里出现 `raise doubts`, `trigger concerns`, `shape interpretation`, `matter`, `become consequential`，必须说明 doubts/concerns/interpretation 的来源和指向。不要让同一个因素同时承担“产生怀疑”和“改变怀疑方向”两个角色，除非明确区分。

示例：

- 弱：`Condition X raises concerns.`
- 强：`The visible departure from a reference point raises doubts about why discretion was used; the identity relation then directs those doubts toward whether the decision favored an in-group client.`

如果用户的文本正是算法治理主题，可以把上句具体化为：`Rejecting AI advice raises doubts because it marks a departure from a relatively neutral recommendation; active representation directs those doubts toward whether discretion was used to benefit a co-identity client.`

### 5. 词语精度检查

理论机制句中要避免过强、过泛或误导的词。

- 用 `visible exercise of discretion` 优于过强的 `deliberate use of discretion`，除非研究能证明主观意图。
- 用 `appears relatively neutral` 优于直接说某个工具、规则、算法建议或制度程序 `is neutral`。
- 用 `direct doubts toward` 优于较抽象的 `channel doubts into`，除非上下文已经很清楚。
- 用 `becomes more consequential` 表示作用更显著；用 `becomes clearer` 只表示解释更清楚。
- 用 `can be understood in light of` 表示解释性对话；用 `is grounded in` 时要确保不是过度断言。

### 6. 输出格式要求

当用户要求“更带劲”“上升到理论层面”“我该怎么和某文献对话”时，优先按以下格式回答：

1. 先用一句话概括真正的理论推进。
2. 分点说明原文献命题、用户发现、机制差异、反推到原文献后的预期变化。
3. 给出一段可直接写入 discussion 的英文。
4. 如果必要，再给短版和强理论版两个选项。
## 机制写法 SOP：嵌入式机制推进法

检查或改写 discussion 中的机制解释时，优先使用“嵌入式机制推进法”。不要默认使用 `One possible explanation is...`、`This pattern points to...` 这类显性提示词；但也不要把它们完全删除或视为错误。更好的机制写法通常是把机制嵌入理论论证，让读者感觉机制是由发现、文献和情境条件自然推出的。

显性机制提示词仍然可以保留在三种情况下：机制证据较弱、作者需要明确降低断言强度；段落跳转较大、需要给读者一个清楚路标；或者改写对象是初稿，先用提示词搭出逻辑骨架，再逐步压缩成更自然的嵌入式写法。

### 核心原则

- 先把结果改写成理论命题，而不是直接报告结果。例如，不写 `we found X`，而写 `the effect of X depends on how the relevant audience interprets Y`。
- 先交代已有文献的 baseline view，再说明本研究如何 refine / qualify / extend 这个 view。
- 用一个机制归属句把发现连到理论机制，例如 `This pattern reflects...`、`This moderation reflects...`、`This contrast hinges on...`。
- 机制链条要按 `theoretical mechanism -> contextual cue -> attribution -> evaluative consequence` 推进，每一句只推进一步。
- 机制句要少用“解释提示词”，多用“理论关系词”：`reflects`、`hinges on`、`rests on`、`depends on`、`is shaped by`、`is consistent with`。
- 如果机制没有被直接检验，要保留谨慎语气：`may`、`appears to`、`suggests`、`can be interpreted as`。

### 推荐结构

1. 理论命题：把经验结果写成一个关于概念、机制或边界条件的判断。
2. 文献基线：说明已有研究通常如何理解这个问题。
3. 贡献动作：用 `refine`、`extend`、`qualify`、`identify a boundary condition` 等动词说明本研究推进了什么。
4. 机制归属：用 `This pattern reflects...` 这类句子把发现接到机制上。
5. 机制链条：按 cue、attribution、evaluation 的顺序推进。
6. 文献回扣：说明这个机制如何解释与前人相同、不同或更细化的地方。

### 可替换句式

- `This pattern reflects [theoretical mechanism], rather than merely [surface result].`
- `This moderation reflects a difference in how [condition A] and [condition B] respond to [audience concern / theoretical tension].`
- `This contrast hinges on [comparison axis], not simply on [observed difference].`
- `This distinction matters because [orientation / institution / cue] speaks more directly to [specific concern].`
- `The relevant mechanism is not [old/simple mechanism], but [new/conditional mechanism].`
- `Under these conditions, [cue] is more likely to be interpreted as [attribution], thereby [evaluative consequence].`
- `This refines prior work by showing that [prior mechanism] depends on [new condition / visible process / information environment].`

### 领域示例：算法治理论文可这样用

以下例子来自算法治理/人机协同决策语境，只能作为迁移示范。处理其他团队成员的论文时，先保留句子的理论功能，再替换为其领域中的对象、线索、机制和评价结果。

- 弱：`One possible explanation is that control-oriented accountability addresses citizens' concerns.`
- 强：`This moderation reflects a difference in how the two orientations respond to the concern raised by discretionary departures from AI advice. Control-oriented accountability may directly address the arbitrariness concern inherent in discretionary overrides.`

- 弱：`Active representation raises favoritism concerns.`
- 强：`Rejecting AI advice raises doubts because it marks a departure from a relatively neutral recommendation; active representation directs those doubts toward whether discretion was used to benefit a co-identity client.`

### 检查问题

- 机制是否由前一句自然推出，而不是突然出现？
- 机制句是否只是说“为什么重要”，还是具体说明了 cue 如何引发 attribution？
- 段落是否把 empirical result 转化成 theoretical claim？
- 是否说明了机制适用的条件，而不是把它写成普遍规律？
- 是否避免了 `important`、`matter`、`explain`、`concern` 等抽象词反复堆叠？
