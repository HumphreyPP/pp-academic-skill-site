# Obsidian-First Section Learning Workflow

Use this reference when explaining the workflow to the user, preparing a research-group demo, or extending the discussion pipeline to other paper sections.

## Core Design

Obsidian is the source of truth. Generated CSV and Markdown files are caches.

```mermaid
flowchart LR
  A["Zotero collection / PDFs"] --> B["Targeted section reading"]
  B --> C["Obsidian source note"]
  C --> C1["Paper-level logic map"]
  C --> C2["Sentence Bank Extracts"]
  C --> D["Sync script"]
  D --> E["CSV cache"]
  D --> F["Markdown reading views"]
  E --> G["Fast writing support"]
  F --> H["Human review and teaching"]
  G --> I["User's draft revision"]
  H --> I
```

## Why This Design

- Obsidian gives the user an all-in-one, browsable knowledge base.
- Paper notes preserve context: why a sentence matters, where it appears, and what argument it supports.
- CSV caches keep retrieval fast, deduplicated, filterable, and easy for Codex to query.
- Markdown reading views give collaborators a clean way to learn without opening raw CSV.

## Artifact Roles

- Zotero: source library and metadata anchor.
- Obsidian paper note: canonical record for one paper's section logic and sentence extracts.
- `Sentence Bank Extracts`: exact source sentences embedded inside the paper note.
- Generated CSV: machine-readable cache, not manually edited.
- Generated Markdown views: lightweight human-facing views grouped by function or theme.

## Discussion Pipeline

The discussion line is the mature first version.

- Reads Discussion / General Discussion / Theoretical Implications first.
- Extracts paragraph function, literature dialogue, CREW, mechanism chains, reusable moves, and exact sentence extracts.
- Best for theory dialogue, mechanism writing, contribution framing, boundary conditions, and cautious interpretation.

## Introduction Pipeline

Build this as a parallel section line, not as a separate system.

Suggested Obsidian fields:

- problem hook
- research object
- literature territory
- gap type
- puzzle or tension
- research question entry
- contribution preview
- transition map
- `Introduction Move Extracts`

Suggested sentence functions:

- problem-opening
- gap-construction
- puzzle-framing
- literature-positioning
- research-question-entry
- contribution-preview
- scope-setting
- transition-to-method

## Methodology Pipeline

Build this after the discussion and introduction workflows are stable.

Suggested Obsidian fields:

- design overview
- case/sample/data justification
- measurement rationale
- identification or inference logic
- model/estimation explanation
- validity threats and responses
- robustness logic
- ethics/transparency note
- `Methodology Move Extracts`

Suggested sentence functions:

- design-justification
- data-source-justification
- sample-boundary
- measurement-rationale
- identification-logic
- model-explanation
- robustness-rationale
- limitation-control
- reproducibility-detail

## Demonstration Script

Use this simple narrative for a research-group presentation:

1. Start from a Zotero collection rather than scattered PDFs.
2. Read only the target section with a fixed analytical lens.
3. Save one Obsidian note per paper as the canonical learning object.
4. Store exact reusable sentences inside the paper note.
5. Regenerate CSV and Markdown views automatically.
6. Use the generated views to support active writing and revision.

## Design Rule

Keep one architecture and multiple section schemas:

`Zotero -> targeted reading -> Obsidian source note -> generated caches/views -> writing support`

Do not create separate unrelated systems for Discussion, Introduction, and Methodology.
