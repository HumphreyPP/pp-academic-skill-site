# Mode Details

## `full-batch`

Use when the user wants to slowly build a reusable discussion-writing corpus.

Default output:

- Obsidian source notes via `discussion-deconstruct-zh`
- `Sentence Bank Extracts` embedded in each source note
- Generated CSV and Markdown reading views via `sentencebank`

Default batch size: 3 papers.

Report:

- papers processed
- Obsidian notes created
- generated cache rows / skipped duplicates
- strongest reusable move from each paper

## `deconstruct-only`

Use when the user wants to understand how a specific article's discussion works.

Output:

- one Obsidian discussion deconstruction note
- no cache refresh unless sentence extracts are added or the user asks

Best for:

- learning a paper's paragraph structure
- comparing a model article with the user's draft
- identifying claim/reason/evidence/warrant patterns

## `sentencebank-only`

Use when the user wants reusable sentence examples.

Output:

- exact quoted sentences added to the relevant Obsidian paper note's `Sentence Bank Extracts`
- generated CSV refreshed from Obsidian

Best for:

- theoretical-dialogue expressions
- boundary-condition sentences
- "moves beyond X to Y" patterns
- "not only X but also Y" conceptual expansions

## `search-use`

Use during active writing revision.

Output:

- no new files by default
- concise evidence from sentence bank and/or Zotero
- recommended wording with reliability notes

Best for:

- checking whether a phrase is mature or coined
- finding ways to write a contribution move
- supporting a transition with published discussion patterns

## `workflow-explain`

Use when the user wants to explain the system to collaborators, present it to a research group, or decide how to extend it to Introduction or Methodology.

Output:

- a short architecture explanation
- a diagram or slide-ready flow if requested
- a distinction between source notes and generated caches
- concrete next steps for Discussion, Introduction, and Methodology pipelines

Best for:

- research-group demonstrations
- deciding whether Obsidian or CSV should be the source of truth
- showing how Zotero, Obsidian, and generated caches work together
- planning parallel section pipelines without duplicating infrastructure

## Candidate Selection

Prefer articles that satisfy at least two of these:

- published in public administration, public policy, governance, management, or adjacent SSCI fields
- contains a clear Discussion / Theoretical Implications section
- engages a named theory or literature stream
- includes AI governance, accountability, discretion, fairness, representative bureaucracy, or citizen evaluation
- has a discussion paragraph that clearly extends, refines, challenges, reconciles, or sets a boundary for prior work

Avoid articles when:

- the discussion only repeats results
- the PDF is unavailable and full text cannot be recovered
- the paper is topically relevant but has weak theoretical dialogue
