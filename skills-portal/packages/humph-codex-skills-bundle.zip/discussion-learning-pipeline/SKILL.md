---
name: discussion-learning-pipeline
description: Use when the user wants to batch learn from published discussion sections by combining Zotero/PDF discovery, Obsidian-first discussion deconstruction notes, and auto-generated sentence-bank caches. Applies to requests to accumulate discussion-writing examples, process multiple papers, compare discussion moves, extract reusable theoretical-dialogue sentences, explain the workflow to a research group, or extend the same learning pipeline to Introduction or Methodology sections.
---

# Discussion Learning Pipeline

## Purpose

Use this as the coordination layer for long-term discussion-writing accumulation. The current architecture is **Obsidian-first**:

- **Obsidian deconstruction notes** are the source of truth: one paper note contains the paper-level logic map and a `Sentence Bank Extracts` section with exact high-value sentences.
- **CSV and Markdown sentence-bank views** are generated caches: use them for fast retrieval, deduplication, filtering, and active writing support.

Do not manually maintain a separate CSV when the same sentence already lives in an Obsidian paper note. Regenerate the cache from Obsidian after updates.

## Related Skills

Load only the needed skill(s):

- `discussion-deconstruct-zh`: use for paper-level Discussion / Theoretical Implications deconstruction and Obsidian notes.
- `sentencebank`: use for exact sentence extraction, Obsidian-to-CSV sync, and generated reading views.
- `zotero:Zotero`: use for local Zotero discovery, metadata, attachment paths, and full-text support.

## Modes

Choose the smallest mode that satisfies the request.

- `full-batch`: for 2-5 papers when the user wants both Obsidian notes and sentence-bank accumulation.
- `deconstruct-only`: for understanding one paper's discussion logic; write only the Obsidian note.
- `sentencebank-only`: for building expression examples; add them to the paper note's `Sentence Bank Extracts`, then refresh generated caches.
- `search-use`: for active writing help; search generated caches and/or Zotero for mature moves, but do not write new notes or rows by default.
- `workflow-explain`: for explaining this system to the user or a research group; read `references/obsidian-first-workflow.md`.

See `references/mode-details.md` for selection criteria and reporting templates.

## Batch Workflow

1. **Define the learning target.** Convert the user's current writing problem into 1-3 search themes, such as accountability move, Van Ryzin dialogue, boundary-condition framing, or human discretion in AI.
2. **Find candidate papers.** Use Zotero first. Prefer papers with strong Discussion, Theoretical Implications, or Public Administration relevance. Avoid broad library scans.
3. **Select a small batch.** Process 3 papers by default; use 5 only when the user explicitly asks for a larger batch or the papers are short.
4. **Read only useful sections.** Start with Discussion / General Discussion / Theoretical Implications. Read abstracts or theory sections only when needed to understand the discussion logic.
5. **Create the Obsidian source note.** Use `discussion-deconstruct-zh` and save concise Obsidian notes with paragraph function, CREW, literature dialogue, reusable moves, and `Sentence Bank Extracts`.
6. **Refresh generated caches.** Use `sentencebank` sync scripts to regenerate CSV and Markdown reading views from Obsidian notes.
7. **Deduplicate and report.** Report notes created/updated, cache rows generated, duplicates skipped, and the strongest reusable move.

## Extraction Standards

For `Sentence Bank Extracts`, be strict:

- Keep 3-8 sentences per paper unless the user asks otherwise.
- Do not store generic result summaries, coefficient prose, or filler transitions.
- Prefer sentences that perform a move: move beyond prior work, contrast with literature, set a boundary condition, explain a mechanism, or reframe a concept.
- Preserve exact wording and citations as they appear in the source sentence when extracted.
- Add a short `evidence_note` explaining why the sentence is reusable.
- Treat Obsidian as the source of truth and CSV as a generated cache unless the user explicitly asks for a standalone CSV workflow.

For Obsidian deconstruction, be compact:

- One line for each paragraph's function.
- One compact CREW chain.
- One literature-dialogue label when relevant.
- One reusable move, quoted only if it is high value.

## Active Writing Use

When the user is revising their own Discussion, prefer `search-use`:

1. Identify the user's desired move.
2. Search the sentence bank first for mature local examples.
3. If sentence-bank evidence is thin, search Zotero full text narrowly.
4. Report whether a proposed expression is supported by:
   - mature ordinary English structure
   - established academic collocation
   - sentence-bank evidence
   - Zotero full-text evidence
5. Offer a conservative rewrite if the phrase looks coined or unsupported.

## Reporting

Keep reports short and useful:

- State the mode used.
- List papers processed or searched.
- Give output paths for Obsidian notes and generated sentence-bank caches.
- Name 1-3 reusable moves learned from the batch.
- Flag uncertain metadata, missing PDFs, or full-text extraction failures.

## Extension Path

Discussion is the first production line. For research-group use, describe the broader design as a **Section Learning Pipeline**:

- `Discussion`: mature now; focuses on theory dialogue, mechanism chains, CREW, and reusable discussion moves.
- `Introduction`: next line; should focus on problematization, gap construction, research question entry, contribution preview, and hook-to-gap transitions.
- `Methodology`: next line; should focus on design justification, measurement rationale, identification logic, robustness logic, and reproducibility language.

When the user asks to present, document, or expand the workflow, read `references/obsidian-first-workflow.md` and keep the explanation audience-friendly.
