---
name: discussion-deconstruct-zh
description: 拆解高质量英文论文 discussion section 的逻辑、理论对话、CREW 论证链和可复用句式，并直接生成精简的 Obsidian Markdown 笔记。适用于：用户提供 PDF、Zotero 条目或论文标题，希望批量分析优秀 discussion 写法；提取段落功能、claim/reason/evidence/warrant、文献比较关系、逻辑推进句和可模仿模板；以及把结果写入 Obsidian，而不是只做一次性聊天总结。
---

# Discussion Deconstruct ZH

## Overview

Use this skill to deconstruct strong published discussion sections into reusable logic maps rather than generic summaries. The goal is to help the user learn how good papers reason, compare with literature, build theory, and close arguments, while saving as many tokens as possible during repeated batch use.

For the user's current workflow, the Obsidian note is the source of truth. If sentence-bank material is extracted, include it in the note's `Sentence Bank Extracts` section so generated CSV and Markdown views can be refreshed later.

Default output target:

- Vault: `D:\Mysoftware\Obsidian Vault\张花盆`
- Folder: `英文写作方法论\顶刊Discussion拆解`
- Index note: `00-Discussion拆解索引.md`
- Source attachment folder: `_sources`

If the vault path is unavailable or cannot be written, fall back to workspace output and say so briefly.

## Core Promise

This skill is **not** for checking the user's own discussion text. It is for **reverse-engineering good papers**.

The skill should answer questions such as:

- What is each paragraph doing?
- How does the author move from findings to theory?
- How does the author compare with prior literature?
- Where is the claim, reason, evidence, and warrant?
- Which sentences are reusable logic moves rather than just content sentences?
- What note should be saved in Obsidian so the user can reuse the pattern later?

## Token-Saving Rules

Batch use is the priority. Save tokens aggressively.

1. Read only the needed section first.
   Default scope is `Discussion`, `General Discussion`, `Theoretical Implications`, or discussion-like paragraphs after results.

2. Do not summarize the whole paper unless necessary.
   Read the abstract, introduction, or methods only when the discussion references a concept, design choice, or hypothesis that cannot otherwise be understood.

3. Record functions, not prose.
   Prefer compact structured notes over elegant explanations.

4. Keep each paragraph entry minimal.
   For each paragraph, capture:
   - one function label
   - one sentence on the paragraph's logic
   - one compact CREW note
   - one literature-dialogue label if relevant
   - one reusable move

5. Quote sparingly.
   Prefer paraphrase. Quote only short high-value sentences that clearly function as a logic-driver, theoretical-dialogue move, or conceptual advancement move.

6. Use the rendering script.
   Produce compact JSON following `references/obsidian-json-schema.md`, then render the full Obsidian note with `scripts/render_discussion_note.py` instead of hand-formatting long markdown every time.

7. Skip low-value detail.
   Do not store long result recaps, coefficient language, or generic filler unless it is necessary to explain the discussion logic.

## Read These References

Load only what you need:

- `references/deconstruction-schema.md`
  Use for paragraph function labels, literature-dialogue taxonomy, and CREW shorthand.

- `references/obsidian-json-schema.md`
  Use when preparing the compact JSON that the rendering script expects.

- `references/token-saving-batch-mode.md`
  Use when processing multiple papers or when the user asks for a note style optimized for later retrieval.

## Workflow

### Step 1: Identify The Source

Use Zotero MCP or a user-provided file to locate the target paper.

Capture only the minimum metadata needed for the note:

- title
- authors
- year
- journal
- DOI if available
- local PDF path if available

### Step 2: Isolate The Discussion

Default boundaries:

- Start at `Discussion`, `General Discussion`, `Theoretical Implications`, `Implications`, or the first discussion-like section after results.
- End at `Conclusion`, `Limitations`, `Practical Implications`, `Future Research`, references, or appendices, unless those sections are integrated into the discussion logic.

If the discussion is embedded after results with no heading, identify the point where the paper stops reporting findings and starts interpreting them.

### Step 3: Deconstruct For Logic, Not Content

For each paragraph, identify:

- paragraph index
- function
- the paragraph's core claim or contribution
- the literature role if present
- the CREW chain in compact form
- the best reusable move

Use the function taxonomy and dialogue taxonomy in `references/deconstruction-schema.md`.

### Step 4: Prepare Compact JSON

Do not draft a long markdown note by hand unless the user explicitly asks for a custom note.

Instead:

1. build compact JSON using `references/obsidian-json-schema.md`
2. keep every field concise
3. pass the JSON to `scripts/render_discussion_note.py`

This is the default path because it saves tokens and keeps notes structurally consistent across batches.

### Step 5: Render The Obsidian Note

Use:

```text
python scripts/render_discussion_note.py --json <path-to-json>
```

By default the script writes to:

```text
D:\Mysoftware\Obsidian Vault\张花盆\英文写作方法论\顶刊Discussion拆解
```

It will:

- create the target folder if missing
- write a standardized note
- include `Sentence Bank Extracts` when `sentence_bank_extracts` exists in the JSON
- copy the source PDF into `_sources` if requested and available
- update `00-Discussion拆解索引.md`

### Step 6: Report Briefly

After writing the note, report only high-signal outcomes:

- note path
- whether source PDF was copied
- whether index was updated
- whether sentence-bank extracts were embedded
- one-line description of the paper's strongest discussion move

## What To Extract

### Section-Level Logic

Capture the discussion's global arc in 3-6 bullets, such as:

- starts by restating the most important finding
- compares that finding with a dominant literature line
- narrows the theoretical contribution
- specifies a mechanism or boundary condition
- acknowledges alternatives or limitations
- closes with broader implications

### Paragraph-Level Function

Use one primary label per paragraph unless two are truly necessary.

Typical labels include:

- finding-to-meaning
- literature-bridge
- theory-refinement
- mechanism
- boundary-condition
- reconciliation
- alternative-interpretation
- limitation
- implication
- closing-synthesis

### Literature Dialogue

If a paragraph mentions prior work, identify:

- target literature or theory
- relation:
  - `confirm`
  - `extend`
  - `refine`
  - `challenge`
  - `boundary-setting`
  - `reconcile`
  - `redirect`
- why that relation matters theoretically

### CREW Chain

**Crew_hotspots must include every paragraph.** 逐段列出，缺什么就标注缺什么——gap is information.

**CREW may span multiple paragraphs.** When 2-3 paragraphs together form one complete argument chain:
- In the paragraph map, include the shared CREW in each contributing paragraph, or note "see P3-P4 CREW"
- In `crew_hotspots`, write a single combined entry covering the paragraphs (e.g. `"para": "P3-P4"`)
- Do not force each paragraph to have its own independent CREW when the author's reasoning is distributed across paragraphs

Use compact rather than essay-like notation.

Minimum elements per CREW entry:

- `Claim` — what the argument wants the reader to believe
- `Reason` — why the reader should believe it
- `Evidence` — what result, example, or citation backs the reason
- `Warrant` — the general principle linking reason to claim

If one of these is weak or missing, note the gap explicitly — do not invent it:

- 缺少 W → 标注 "W: 缺失"，该段可能只是结果复述或结构预示
- 缺少 E → 标注 "E: 缺失"，该段可能是纯理论推论
- P1（开篇结构预示段）通常缺少完整 CREW，如实标注即可

Gap is information. A paragraph with no warrant tells the user something important: the author is reporting, not reasoning. A multi-paragraph CREW tells the user something else: the author's argument is complex enough to require distributed reasoning.

### Reusable Moves

Extract only high-value moves, for example:

- a sentence that pivots from result to theory
- a sentence that reframes a concept
- a sentence that sets a boundary condition
- a sentence that diplomatically compares with prior work
- a sentence that closes the paragraph with broader implications

## Language Distribution (中英文分布)

The output note uses a **mixed Chinese/English format** by default. This is a fixed convention, not a per-paper choice.

### Chinese (中文撰写 — 分析性、解释性、反思性内容)

| Field | Rationale |
|-------|-----------|
| `ultra_short_take` | 用户快速扫描时直接理解论文贡献 |
| `section_logic[]` | 讨论的全局逻辑弧线 |
| `core_move` | 论文最强的理论推进动作 |
| `paragraph_map[].logic` | 每段逻辑做什么 |
| `paragraph_map[].dialogue` | 该段与哪些文献对话，中文描述关系 |
| `paragraph_map[].crew` | C/R/E/W 用中文写，关键术语保留英文 |
| `paragraph_map[].move` | 可复用句式的功能说明 |
| `literature_dialogue[].stakes` | 该文献对话的理论含义 |
| `crew_hotspots[].claim / reason / evidence / warrant` | 论证要素内容 |
| `logic_drivers[]` | 关键逻辑推进节点的中文描述 |
| `reusable_moves[]` | 英文句式模板 + 中文功能说明 |
| `for_my_writing[]` | 可迁移的写作教训 |

### English (保留英文 — 术语、标签、元数据)

| Field | Rationale |
|-------|-----------|
| `title`, `authors`, `year`, `journal`, `doi` | 元数据，保持精确可检索 |
| `apa_citation` | 引用格式不可翻译 |
| `paragraph_map[].function` | 段落功能标签，与 classification taxonomy 一致 |
| `literature_dialogue[].target` | 文献/理论名称留英文 |
| `literature_dialogue[].role` | 分类标签：ally / target / contrast / evidence-source / warrant-source |
| `literature_dialogue[].relation` | 分类标签：confirm / extend / refine / challenge / boundary-setting / reconcile / redirect |
| `tags[]` | 保持英文便于跨笔记检索 |

### Reusable moves 双语格式

每条 move 使用 **英文句式模板 + 中文功能说明**，以破折号分隔：

```
- P2: 'Compared with human handling, AI usage has a significant negative effect on X, supporting the tenets of Y thesis'——finding→theory confirmation: 对比对象→效应方向→理论对接
```

英文部分是可直接填入内容的句式骨架，中文部分解释这个句式的功能和适用场景。

## Default Note Shape

Unless the user asks for a different format, the rendered note should contain:

1. APA citation
2. Ultra-short take (中文)
3. Section logic (中文)
4. Paragraph map (Function 英文，其余中文)
5. Literature dialogue map (Target/Role/Relation 英文，Stakes 中文)
6. CREW hotspots (中文)
7. Logic-driver sentences or moves (中文)
8. Reusable sentence moves (英文句式 + 中文说明)
9. Sentence Bank Extracts (exact source sentences)
10. Lessons for my writing (中文)

The full field schema is defined in `references/obsidian-json-schema.md`.

## Batch Mode

When processing many papers:

1. keep one note per paper
2. keep one shared index note
3. do not write long prose explanations in each note
4. prefer tables and short bullets
5. log only the strongest 1-3 transferable lessons per paper

Use `references/token-saving-batch-mode.md` for exact compression rules.

## Quality Bar

A good deconstruction note should let the user answer:

- What is this discussion's main reasoning arc?
- What is each paragraph doing?
- How does the author build theory from findings?
- How does the author handle prior literature?
- What exact move can I imitate in my own writing?

If a note cannot answer those questions quickly, it is too descriptive and not deconstructive enough.

## Guardrails

- Do not turn the note into a summary of the whole paper.
- Do not copy large blocks of prose.
- Do not store low-value filler or long methodological detail unless the discussion logic depends on it.
- Do not invent literature relations or warrants that are not supported by the text.
- Do not confuse result-reporting sentences with logic-driver sentences.
- Do not lose the distinction between the author's findings and prior studies' findings.
- Do not over-praise a discussion just because it sounds polished; identify what work each paragraph actually performs.

## Example Prompts This Skill Should Handle

- `拆解这篇 SSCI 论文的 discussion，写进我的 Obsidian。`
- `批量分析这 10 篇文章的 discussion 逻辑，每篇都生成一个精简笔记。`
- `找出这篇 discussion 最值得模仿的理论对话句式和逻辑推进句。`
- `把这篇 discussion 拆成 paragraph function + CREW + literature dialogue。`

## Minimal Final Checklist

Before finishing, verify:

- only the necessary sections were read
- the note uses compact structured output
- each paragraph has a primary function label
- literature relations are identified where relevant
- CREW is captured in compact form
- at least one reusable move is extracted
- exact sentence-bank extracts are embedded when the user wants reusable sentences
- the Obsidian note and index were written or a brief fallback was reported
- remind the user: skill changes (if any were made) need `git commit` / `git push` by the user to persist — Claude cannot push
