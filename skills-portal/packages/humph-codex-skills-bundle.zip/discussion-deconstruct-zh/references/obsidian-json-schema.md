# Obsidian JSON Schema

Use this schema to prepare compact data for `scripts/render_discussion_note.py`.

The renderer will format the final markdown note, so keep field values concise.

## Required top-level fields

```json
{
  "title": "",
  "authors": "",
  "year": "",
  "journal": "",
  "doi": "",
  "apa_citation": "",
  "ultra_short_take": "",
  "core_move": "",
  "section_logic": [],
  "paragraph_map": [],
  "literature_dialogue": [],
  "crew_hotspots": [],
  "logic_drivers": [],
  "reusable_moves": [],
  "sentence_bank_extracts": [],
  "for_my_writing": []
}
```

## Optional fields

```json
{
  "source_pdf": "",
  "tags": [],
  "note_name": "",
  "folder": "",
  "source_embed_name": ""
}
```

## `paragraph_map` row shape

```json
{
  "para": "P1",
  "function": "finding-to-meaning",
  "logic": "开篇命名核心发现并立即陈述其理论含义，为后续三段讨论提供路线图。",
  "dialogue": "refine prior fairness literature (refine关系)",
  "crew": "C: 公平感是解释性的而非客观的；R: 可见的建议处理过程塑造公平感知；E: 效应集中在结果不透明的条件下；W: 当正确性难以判断时，人们从过程线索推断公平性",
  "move": "result-to-theory pivot: 从'发现X'立即转向'这意味着Y理论需要修正'"
}
```

Keep the `crew` field compressed. Use semicolons, not a paragraph. Key English terms (e.g. variable names, theory names) may be kept inline.

## `literature_dialogue` row shape

```json
{
  "para": "P2",
  "target": "prior accountability literature",
  "role": "target",
  "relation": "boundary-setting",
  "stakes": "表明问责逻辑的成立取决于结果不透明度这一边界条件"
}
```

## `crew_hotspots` row shape

```json
{
  "para": "P3",
  "claim": "AI降低一线裁量权，但官僚仍对AI持开放态度",
  "reason": "AI的效率与一致性优势超过了对自主权损失的顾虑",
  "evidence": "willingness-to-implement上AI组显著高于人类处理组 (β=0.226, p<0.001)",
  "warrant": "工具性收益感知与自主权关切是技术接受的两个独立维度"
}
```

## `logic_drivers` item shape

Use one line per item, written in Chinese.

```json
[
  "P2: 从经验结果（AI降低discretion）直接转向理论定位（确认curtailment thesis），跳过渐进过渡",
  "P4: 在陈述作者结论之前先承认一个竞争性解释，然后以证据回应"
]
```

## `reusable_moves` item shape

English sentence template + Chinese functional explanation, separated by `——`.

```json
[
  "Rather than treating X as..., the authors show that...——概念重塑: 将X从A框架重新定位到B框架",
  "This difference is theoretically important because...——差异的理论化: 不仅报告差异存在，还解释差异为什么对理论有意义"
]
```

## `sentence_bank_extracts` row shape

Use this optional field when the note should also serve as the source of truth for the sentence bank. Preserve exact source wording in `quote`.

```json
[
  {
    "function": "theoretical-dialogue",
    "quote": "This finding extends prior work by showing that...",
    "section_label": "Discussion",
    "paragraph_index": "P3",
    "evidence_note": "Positions the finding against a named literature stream."
  }
]
```

Keep 3-8 high-value sentences per paper unless the user requests broader coverage. Use the same function labels as the sentence-bank workflow, such as `logic-driver`, `theoretical-dialogue`, `conceptual-advancement`, `mechanism-or-explanation`, `literature-comparison`, `qualification-or-hedging`, `transition-or-synthesis`, or `contribution-statement`.

## `for_my_writing` item shape

Focus on transfer, not admiration. Write in Chinese.

```json
[
  "与先前文献比较时，明确命名关系类型（extend/refine/challenge）而非只说'不同于以往研究'",
  "在limitation句之后添加一句bounded value陈述，避免以弱点收尾"
]
```

## Language Rules (语言规则)

The note uses a **fixed Chinese/English mixed format**. Follow the split below when filling each field.

### Chinese only (中文)

`ultra_short_take`, `core_move`, `section_logic[]`, `logic_drivers[]`, `for_my_writing[]` — all values must be written in Chinese.

For `paragraph_map[]`:
- `logic`, `dialogue`, `crew`, `move` — Chinese, with key English terms preserved inline where natural

For `literature_dialogue[]`:
- `stakes` — Chinese

For `crew_hotspots[]`:
- `claim`, `reason`, `evidence`, `warrant` — Chinese, with key English terms preserved inline

### English only (英文)

`title`, `authors`, `year`, `journal`, `doi`, `apa_citation` — English/metadata.

For `paragraph_map[]`:
- `function` — English label from the taxonomy

For `literature_dialogue[]`:
- `target`, `role`, `relation` — English labels

`tags[]` — English for cross-note searchability.

### Bilingual (双语)

`reusable_moves[]` — English sentence template followed by Chinese functional explanation, separated by `——`:

```
'English sentence pattern here'——中文功能说明
```

### Field language reference

| Field | Language |
|-------|----------|
| `ultra_short_take` | zh |
| `core_move` | zh |
| `section_logic[]` | zh |
| `paragraph_map[].para` | en |
| `paragraph_map[].function` | en |
| `paragraph_map[].logic` | zh |
| `paragraph_map[].dialogue` | zh |
| `paragraph_map[].crew` | zh |
| `paragraph_map[].move` | zh |
| `literature_dialogue[].para` | en |
| `literature_dialogue[].target` | en |
| `literature_dialogue[].role` | en |
| `literature_dialogue[].relation` | en |
| `literature_dialogue[].stakes` | zh |
| `crew_hotspots[].para` | en |
| `crew_hotspots[].claim` | zh |
| `crew_hotspots[].reason` | zh |
| `crew_hotspots[].evidence` | zh |
| `crew_hotspots[].warrant` | zh |
| `logic_drivers[]` | zh |
| `reusable_moves[]` | en+zh bilingual |
| `sentence_bank_extracts[].function` | en |
| `sentence_bank_extracts[].quote` | exact source language |
| `sentence_bank_extracts[].section_label` | en/source |
| `sentence_bank_extracts[].paragraph_index` | en |
| `sentence_bank_extracts[].evidence_note` | zh/en |
| `for_my_writing[]` | zh |
| `tags[]` | en |

## Compression Rules

- `ultra_short_take`: 1-3 sentences
- `section_logic`: 3-6 bullets
- `paragraph_map`: one row per paragraph
- `literature_dialogue`: include only paragraphs where literature matters
- `crew_hotspots`: include only the most instructive 3-8 paragraphs
- `logic_drivers`: keep to the strongest 3-8 items
- `reusable_moves`: keep to the strongest 3-10 items
- `sentence_bank_extracts`: keep to the strongest 3-8 exact sentences
- `for_my_writing`: keep to 3-6 items
