---
name: discussion-deconstruct-zh
description: Deconstruct strong published discussion sections into compact Obsidian notes. Extract paragraph logic, literature dialogue, CREW chains, and reusable sentence moves with a workflow optimized for repeated batch use and low token cost.
---

# Discussion Deconstruct ZH

## Overview

Use this skill to reverse-engineer strong published `discussion` sections and save the results as compact, reusable Obsidian notes.

This skill is for learning from **other people's good papers**, not for checking the user's own discussion draft. The output should help the user see how a strong discussion section is built paragraph by paragraph, how it talks to literature, how it turns findings into theory, and what exact moves are worth imitating later.

Default output target:

- Vault: `D:\Mysoftware\Obsidian Vault\张花盆`
- Folder: `英文写作方法论\顶刊Discussion拆解`
- Index note: `00-Discussion拆解索引.md`
- Source attachment folder: `_sources`

If the vault path is unavailable or cannot be written, fall back to a workspace note and say so briefly.

## Core Promise

This skill should answer the following questions quickly:

- What is each paragraph doing?
- How does the author move from findings to theory?
- How does the author compare with prior literature?
- Where is the `Claim`, `Reason`, `Evidence`, and `Warrant`?
- Which sentences are logic-driving moves rather than content-only sentences?
- What compact note should be written into Obsidian so the pattern can be reused later?

## Token-Saving Rules

Batch use is the priority. Save tokens aggressively.

1. Read only the needed section first.
   Default scope is `Discussion`, `General Discussion`, `Theoretical Implications`, or discussion-like paragraphs after results.

2. Do not summarize the whole paper unless necessary.
   Open the abstract, introduction, methods, or results only when the discussion cannot be decoded without them.

3. Record functions, not prose.
   Prefer compact structured notes over polished explanations.

4. Keep each paragraph entry minimal.
   For each paragraph, capture:
   - one primary function label
   - one sentence on the paragraph's logic
   - one compact CREW note
   - one literature-dialogue label if relevant
   - one reusable move

5. Quote sparingly.
   Prefer paraphrase. Quote only short high-value wording that clearly functions as a result-to-theory pivot, literature-dialogue move, conceptual reframing move, or closing synthesis move.

6. Use the rendering script instead of hand-formatting long notes.
   Build compact JSON following `references/obsidian-json-schema.md`, then render the final markdown note with `scripts/render_discussion_note.py`.

7. Skip low-value detail.
   Do not store long result recaps, coefficient language, or generic filler unless it is necessary to explain the discussion logic.

## Read These References

Load only what you need:

- `references/deconstruction-schema.md`
  Use for paragraph function labels, literature-dialogue taxonomy, and CREW shorthand.

- `references/obsidian-json-schema.md`
  Use when preparing the compact JSON that the rendering script expects.

- `references/token-saving-batch-mode.md`
  Use when processing many papers or when the user explicitly wants maximum token efficiency.

## Workflow

### Step 1: Identify The Source

Use Zotero MCP or a user-provided file to locate the target paper.

Capture only the minimum metadata needed for the note:

- title
- authors
- year
- journal
- DOI if available
- local PDF path if available

### Step 2: Isolate The Discussion

Default boundaries:

- Start at `Discussion`, `General Discussion`, `Theoretical Implications`, `Implications`, or the first discussion-like section after results.
- End at `Conclusion`, `Limitations`, `Practical Implications`, `Future Research`, references, or appendices, unless those sections are integrated into the discussion logic.

If the discussion is embedded after results with no heading, identify the point where the paper stops reporting findings and starts interpreting them.

### Step 3: Deconstruct For Logic, Not Content

For each paragraph, identify:

- paragraph index
- function
- the paragraph's core claim or contribution
- the literature role if present
- the CREW chain in compact form
- the best reusable move

Use the function taxonomy and dialogue taxonomy in `references/deconstruction-schema.md`.

### Step 4: Prepare Compact JSON

Do not draft a long markdown note by hand unless the user explicitly asks for a custom note.

Instead:

1. build compact JSON using `references/obsidian-json-schema.md`
2. keep every field concise
3. pass the JSON to `scripts/render_discussion_note.py`

This is the default path because it saves tokens and keeps notes structurally consistent across batches.

### Step 5: Render The Obsidian Note

Use:

```text
python scripts/render_discussion_note.py --json <path-to-json>
```

By default the script writes to:

```text
D:\Mysoftware\Obsidian Vault\张花盆\英文写作方法论\顶刊Discussion拆解
```

It will:

- create the target folder if missing
- write a standardized note
- copy the source PDF into `_sources` if requested and available
- update `00-Discussion拆解索引.md`

### Step 6: Report Briefly

After writing the note, report only high-signal outcomes:

- note path
- whether the source PDF was copied
- whether the index was updated
- one-line description of the paper's strongest discussion move

## What To Extract

### Section-Level Logic

Capture the discussion's global arc in 3-6 bullets, such as:

- restates the most important finding
- compares that finding with a dominant literature line
- narrows the theoretical contribution
- specifies a mechanism or boundary condition
- acknowledges alternatives or limitations
- closes with broader implications

### Paragraph-Level Function

Use one primary label per paragraph unless two are truly necessary.

Typical labels include:

- `finding-to-meaning`
- `literature-bridge`
- `theory-refinement`
- `mechanism`
- `boundary-condition`
- `reconciliation`
- `alternative-interpretation`
- `limitation`
- `implication`
- `closing-synthesis`

### Literature Dialogue

If a paragraph mentions prior work, identify:

- target literature or theory
- relation:
  - `confirm`
  - `extend`
  - `refine`
  - `challenge`
  - `boundary-setting`
  - `reconcile`
  - `redirect`
- why that relation matters theoretically

### CREW Chain

Use compact rather than essay-like notation.

Minimum standard:

- `Claim`
- `Reason`
- `Evidence`
- `Warrant`

If one of these is weak or missing, note the gap explicitly.

### Reusable Moves

Extract only high-value moves, for example:

- a sentence that pivots from result to theory
- a sentence that reframes a concept
- a sentence that sets a boundary condition
- a sentence that diplomatically compares with prior work
- a sentence that closes the paragraph with broader implications

## Default Note Shape

Unless the user asks for a different format, the rendered note should contain:

1. APA citation
2. Ultra-short take
3. Section logic
4. Paragraph map
5. Literature dialogue map
6. CREW hotspots
7. Logic-driver sentences or moves
8. Reusable sentence moves
9. Lessons for my writing

The full field schema is defined in `references/obsidian-json-schema.md`.

## Batch Mode

When processing many papers:

1. keep one note per paper
2. keep one shared index note
3. do not write long prose explanations in each note
4. prefer tables and short bullets
5. log only the strongest 1-3 transferable lessons per paper

Use `references/token-saving-batch-mode.md` for exact compression rules.

## Quality Bar

A good deconstruction note should let the user answer:

- What is this discussion's main reasoning arc?
- What is each paragraph doing?
- How does the author build theory from findings?
- How does the author handle prior literature?
- What exact move can I imitate in my own writing?

If a note cannot answer those questions quickly, it is too descriptive and not deconstructive enough.

## Guardrails

- Do not turn the note into a summary of the whole paper.
- Do not copy large blocks of prose.
- Do not store low-value filler or long methodological detail unless the discussion logic depends on it.
- Do not invent literature relations or warrants that are not supported by the text.
- Do not confuse result-reporting sentences with logic-driver sentences.
- Do not lose the distinction between the author's findings and prior studies' findings.
- Do not over-praise a discussion just because it sounds polished; identify what work each paragraph actually performs.

## Example Prompts This Skill Should Handle

- `拆解这篇 SSCI 论文的 discussion，写进我的 Obsidian。`
- `批量分析这 10 篇文章的 discussion 逻辑，每篇都生成一个精简笔记。`
- `找出这篇 discussion 最值得模仿的理论对话句式和逻辑推进句。`
- `把这篇 discussion 拆成 paragraph function + CREW + literature dialogue。`

## Minimal Final Checklist

Before finishing, verify:

- only the necessary sections were read
- the note uses compact structured output
- each paragraph has a primary function label
- literature relations are identified where relevant
- CREW is captured in compact form
- at least one reusable move is extracted
- the Obsidian note and index were written or a brief fallback was reported
