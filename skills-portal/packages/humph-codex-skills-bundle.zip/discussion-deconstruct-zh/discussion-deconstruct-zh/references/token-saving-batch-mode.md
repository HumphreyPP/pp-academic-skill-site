# Token-Saving Batch Mode

Use this mode by default when the user wants many papers processed.

## Main Rule

Favor **retrievability** over elegance.

The note should be useful six weeks later when the user scans it quickly, not beautiful on the day it is written.

## Read Less

- Start with the discussion only.
- Open the abstract only if you need the study aim.
- Open the introduction only if a discussion claim depends on a concept that is not otherwise clear.
- Open the methods or results only when the warrant depends on design or when a paragraph references a result too vaguely to decode.

## Write Less

Do not write:

- long paper summaries
- repeated result descriptions
- generic praise
- whole-paragraph paraphrases
- multiple versions of the same move

Instead write:

- one-line paragraph functions
- compressed CREW
- explicit literature relation labels
- one reusable move per paragraph at most

## Quote Budget

Prefer paraphrase.

If you quote, keep the total note lean:

- best practice: 0-3 short quotations
- only quote if the exact wording is unusually reusable

## Selection Rules

When time or tokens are tight, prioritize:

1. paragraphs with clear result-to-theory pivots
2. paragraphs that compare with prior literature
3. paragraphs that express mechanisms or boundary conditions
4. closing paragraphs that model synthesis

Skip:

- paragraphs that mostly recap results
- routine practical implications with little transfer value
- generic future research filler

## Batch Consistency

Across many papers, keep the same:

- folder
- note title pattern
- frontmatter fields
- paragraph map columns
- literature dialogue labels
- CREW shorthand
- index note format

Consistency lowers future token costs because later notes can be updated by analogy rather than re-invented.

