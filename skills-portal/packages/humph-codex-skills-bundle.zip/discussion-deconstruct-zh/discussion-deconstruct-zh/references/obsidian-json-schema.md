# Obsidian JSON Schema

Use this schema to prepare compact data for `scripts/render_discussion_note.py`.

The renderer will format the final markdown note, so keep field values concise.

## Required top-level fields

```json
{
  "title": "",
  "authors": "",
  "year": "",
  "journal": "",
  "doi": "",
  "apa_citation": "",
  "ultra_short_take": "",
  "core_move": "",
  "section_logic": [],
  "paragraph_map": [],
  "literature_dialogue": [],
  "crew_hotspots": [],
  "logic_drivers": [],
  "reusable_moves": [],
  "for_my_writing": []
}
```

## Optional fields

```json
{
  "source_pdf": "",
  "tags": [],
  "note_name": "",
  "folder": "",
  "source_embed_name": ""
}
```

## `paragraph_map` row shape

```json
{
  "para": "P1",
  "function": "finding-to-meaning",
  "logic": "Names the main result and immediately states why it matters.",
  "dialogue": "refine prior fairness literature",
  "crew": "C: fairness is interpretive; R: visible advice handling matters; E: effect concentrates under opacity; W: people infer fairness from cues when correctness is unclear",
  "move": "result-to-theory pivot"
}
```

Keep the `crew` field compressed. Use semicolons, not a paragraph.

## `literature_dialogue` row shape

```json
{
  "para": "P2",
  "target": "prior accountability literature",
  "role": "target",
  "relation": "boundary-setting",
  "stakes": "shows that accountability logic depends on outcome opacity"
}
```

## `crew_hotspots` row shape

```json
{
  "para": "P3",
  "claim": "",
  "reason": "",
  "evidence": "",
  "warrant": ""
}
```

## `logic_drivers` item shape

Use one line per item.

```json
[
  "P2: shifts from empirical pattern to interpretive mechanism",
  "P4: acknowledges a competing explanation before restating the author's conclusion"
]
```

## `reusable_moves` item shape

Use compact sentence patterns or move descriptions.

```json
[
  "Rather than treating X as..., the authors show that...",
  "This difference is theoretically important because..."
]
```

## `for_my_writing` item shape

Focus on transfer, not admiration.

```json
[
  "When I compare with prior work, name the relation explicitly rather than only saying 'different from previous studies'.",
  "After a limitation sentence, add a bounded value sentence instead of ending on weakness."
]
```

## Compression Rules

- `ultra_short_take`: 1-3 sentences
- `section_logic`: 3-6 bullets
- `paragraph_map`: one row per paragraph
- `literature_dialogue`: include only paragraphs where literature matters
- `crew_hotspots`: include only the most instructive 3-8 paragraphs
- `logic_drivers`: keep to the strongest 3-8 items
- `reusable_moves`: keep to the strongest 3-10 items
- `for_my_writing`: keep to 3-6 items

