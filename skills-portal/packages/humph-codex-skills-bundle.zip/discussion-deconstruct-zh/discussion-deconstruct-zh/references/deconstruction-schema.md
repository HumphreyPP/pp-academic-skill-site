# Deconstruction Schema

Use this file to classify discussion logic quickly and consistently.

## 1. Section-Level Arc

Map the whole discussion in 3-6 bullets using these common moves:

- `core-finding`: opens by naming the main result
- `meaning`: interprets what that result means
- `literature-placement`: compares with prior studies or theory
- `theory-move`: reframes a concept, mechanism, or explanation
- `boundary`: limits where the claim applies
- `alternative`: acknowledges another explanation
- `limitation`: states what cannot be concluded
- `implication`: extends to theory, practice, or future research
- `close`: synthesizes what the reader should remember

## 2. Paragraph Function Labels

Assign one primary label per paragraph.

- `finding-to-meaning`
  The paragraph converts an empirical result into a theoretical point.

- `literature-bridge`
  The paragraph connects the paper's finding to prior work.

- `theory-refinement`
  The paragraph sharpens or modifies a concept, mechanism, or theory.

- `mechanism`
  The paragraph explains how or why the effect happens.

- `boundary-condition`
  The paragraph specifies when the logic holds or fails.

- `reconciliation`
  The paragraph helps explain why different strands of literature can both be right.

- `alternative-interpretation`
  The paragraph acknowledges and responds to another reading of the data.

- `limitation`
  The paragraph marks what the study cannot firmly claim.

- `implication`
  The paragraph extends the argument toward a broader theoretical or practical implication.

- `closing-synthesis`
  The paragraph closes the section by restating what the discussion now establishes.

## 3. Literature Dialogue Relations

If a paragraph mentions prior work, classify the relation.

- `confirm`
  The paper supports a prior claim.

- `extend`
  The paper applies a prior claim to a new context, object, or level.

- `refine`
  The paper makes a prior claim more specific, conditional, or differentiated.

- `challenge`
  The paper questions a prior claim's validity or completeness.

- `boundary-setting`
  The paper shows that a prior claim holds only under certain conditions.

- `reconcile`
  The paper explains how apparently conflicting findings can coexist.

- `redirect`
  The paper shifts the debate from one object or framing to another.

## 4. Literature Roles

Give each cited work a role if it matters to the paragraph.

- `ally`
  Supports the current claim.

- `target`
  Is being refined, challenged, or bounded.

- `contrast`
  Creates tension or difference.

- `evidence-source`
  Supplies external evidence.

- `warrant-source`
  Supplies the theory or reasoning principle connecting reason to claim.

- `reasoning-model`
  Serves as a model for how the author structures an argument.

## 5. CREW Shorthand

Capture each paragraph with compact fields, not long prose.

- `C`
  What does the paragraph want the reader to believe?

- `R`
  Why should the reader believe it?

- `E`
  What result, example, or citation supports that reason?

- `W`
  What general principle links the reason to the claim?

Use terse phrases, not full essays.

## 6. Logic-Driver Sentence Guide

Extract a sentence or move only if it does one of these:

- pivots from result to interpretation
- sets up a literature comparison
- reframes a concept
- states a mechanism
- introduces a boundary condition
- acknowledges an alternative view and answers it
- closes with a broader implication

Ignore sentences that merely repeat results or add generic filler.

## 7. Reusable Move Types

When you save a move for later imitation, tag it loosely by type:

- `result-to-theory`
- `theory-dialogue`
- `mechanism`
- `boundary`
- `qualification`
- `limitation-to-value`
- `closing-implication`

