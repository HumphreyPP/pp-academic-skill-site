from __future__ import annotations

import argparse
import json
import re
import shutil
from datetime import date
from pathlib import Path


DEFAULT_VAULT = Path("D:/Mysoftware/Obsidian Vault/张花盆")
DEFAULT_FOLDER = Path("英文写作方法论/顶刊Discussion拆解")
DEFAULT_INDEX = "00-Discussion拆解索引.md"


def slugify(text: str, limit: int = 48) -> str:
    text = re.sub(r"[^\w\s-]", "", text, flags=re.UNICODE)
    text = re.sub(r"[\s_]+", "-", text.strip(), flags=re.UNICODE)
    text = re.sub(r"-{2,}", "-", text).strip("-")
    return text[:limit] or "Untitled"


def first_author_surname(authors: str) -> str:
    if not authors:
        return "Unknown"
    first = re.split(r"[;&]| and ", authors)[0].strip()
    if "," in first:
        first = first.split(",", 1)[0].strip()
    else:
        first = first.split()[0].strip()
    return re.sub(r"[^\w-]", "", first, flags=re.UNICODE) or "Unknown"


def today_iso() -> str:
    return date.today().isoformat()


def escape_cell(text: str) -> str:
    text = str(text or "").replace("\n", " ").strip()
    return text.replace("|", "\\|")


def bullet_block(items: list[str]) -> str:
    if not items:
        return "- "
    return "\n".join(f"- {item}" for item in items)


def table(headers: list[str], rows: list[list[str]]) -> str:
    if not rows:
        return ""
    head = "| " + " | ".join(headers) + " |"
    sep = "| " + " | ".join(["---"] * len(headers)) + " |"
    body = "\n".join("| " + " | ".join(escape_cell(cell) for cell in row) + " |" for row in rows)
    return "\n".join([head, sep, body])


def copy_source_pdf(data: dict, sources_dir: Path) -> str:
    source_pdf = data.get("source_pdf")
    if not source_pdf:
        return ""
    src = Path(source_pdf)
    if not src.exists():
        return ""
    sources_dir.mkdir(parents=True, exist_ok=True)
    name = data.get("source_embed_name") or src.name
    dest = sources_dir / name
    if src.resolve() != dest.resolve():
        shutil.copy2(src, dest)
    return name


def build_frontmatter(data: dict, tags: list[str]) -> str:
    tag_lines = "\n".join(f"  - {tag}" for tag in tags)
    return (
        "---\n"
        "type: discussion-deconstruction\n"
        f"created: {today_iso()}\n"
        "source: published-paper\n"
        f"authors: {data.get('authors', '')}\n"
        f"year: {data.get('year', '')}\n"
        f"journal: {data.get('journal', '')}\n"
        f"doi: {data.get('doi', '')}\n"
        "tags:\n"
        f"{tag_lines}\n"
        "---"
    )


def render_note(data: dict, pdf_embed_name: str) -> str:
    tags = data.get("tags") or [
        "discussion拆解",
        "theory-dialogue",
        "CREW",
    ]

    para_rows = []
    for row in data.get("paragraph_map", []):
        para_rows.append(
            [
                row.get("para", ""),
                row.get("function", ""),
                row.get("logic", ""),
                row.get("dialogue", ""),
                row.get("crew", ""),
                row.get("move", ""),
            ]
        )

    dialogue_rows = []
    for row in data.get("literature_dialogue", []):
        dialogue_rows.append(
            [
                row.get("para", ""),
                row.get("target", ""),
                row.get("role", ""),
                row.get("relation", ""),
                row.get("stakes", ""),
            ]
        )

    crew_rows = []
    for row in data.get("crew_hotspots", []):
        crew_rows.append(
            [
                row.get("para", ""),
                row.get("claim", ""),
                row.get("reason", ""),
                row.get("evidence", ""),
                row.get("warrant", ""),
            ]
        )

    sections = [
        build_frontmatter(data, tags),
        "",
        f"# {data.get('title', 'Untitled')} - Discussion拆解",
        "",
        "## APA Citation",
        "",
        data.get("apa_citation", ""),
        "",
        "## Ultra-short Take",
        "",
        data.get("ultra_short_take", ""),
    ]

    if pdf_embed_name:
        sections.extend(
            [
                "",
                "## Source PDF",
                "",
                f"![[_sources/{pdf_embed_name}]]",
            ]
        )

    sections.extend(
        [
            "",
            "## Section Logic",
            "",
            bullet_block(data.get("section_logic", [])),
            "",
            "## Paragraph Map",
            "",
            table(
                ["Para", "Function", "Logic", "Dialogue", "CREW", "Reusable move"],
                para_rows,
            )
            or "_No paragraph map captured._",
            "",
            "## Literature Dialogue",
            "",
            table(
                ["Para", "Target", "Role", "Relation", "Theoretical stakes"],
                dialogue_rows,
            )
            or "_No literature-dialogue rows captured._",
            "",
            "## CREW Hotspots",
            "",
            table(
                ["Para", "Claim", "Reason", "Evidence", "Warrant"],
                crew_rows,
            )
            or "_No CREW hotspots captured._",
            "",
            "## Logic Drivers",
            "",
            bullet_block(data.get("logic_drivers", [])),
            "",
            "## Reusable Moves",
            "",
            bullet_block(data.get("reusable_moves", [])),
            "",
            "## For My Writing",
            "",
            bullet_block(data.get("for_my_writing", [])),
        ]
    )

    return "\n".join(sections).strip() + "\n"


def ensure_index(index_path: Path) -> None:
    if index_path.exists():
        return
    index_path.parent.mkdir(parents=True, exist_ok=True)
    index_path.write_text(
        "# 顶刊 Discussion 拆解索引\n\n"
        "| Updated | Authors | Year | Journal | Core move | Note |\n"
        "| --- | --- | --- | --- | --- | --- |\n",
        encoding="utf-8",
    )


def upsert_index(index_path: Path, note_name: str, data: dict) -> None:
    ensure_index(index_path)
    text = index_path.read_text(encoding="utf-8")
    link = f"[[{note_name}]]"
    rows = text.splitlines()
    if any(link in row for row in rows):
        return
    row = (
        f"| {today_iso()} | {escape_cell(data.get('authors', ''))} | "
        f"{escape_cell(data.get('year', ''))} | {escape_cell(data.get('journal', ''))} | "
        f"{escape_cell(data.get('core_move', ''))} | {link} |"
    )
    rows.append(row)
    index_path.write_text("\n".join(rows).rstrip() + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Render a discussion deconstruction note into Obsidian.")
    parser.add_argument("--json", required=True, help="Path to compact JSON input.")
    parser.add_argument("--vault", default=str(DEFAULT_VAULT), help="Obsidian vault path.")
    parser.add_argument("--folder", default=str(DEFAULT_FOLDER), help="Folder inside the vault.")
    parser.add_argument("--index-name", default=DEFAULT_INDEX, help="Index note filename.")
    parser.add_argument("--copy-source-pdf", action="store_true", help="Copy source PDF into _sources.")
    args = parser.parse_args()

    json_path = Path(args.json)
    data = json.loads(json_path.read_text(encoding="utf-8"))

    vault = Path(args.vault)
    folder = Path(args.folder)
    target_dir = vault / folder
    target_dir.mkdir(parents=True, exist_ok=True)

    note_name = data.get("note_name")
    if not note_name:
        year = str(data.get("year", "")).strip() or "YYYY"
        author = first_author_surname(data.get("authors", ""))
        short_title = slugify(data.get("title", "Untitled"), limit=42)
        note_name = f"{year}-{author}-{short_title}-Discussion拆解.md"

    sources_dir = target_dir / "_sources"
    pdf_embed_name = ""
    if args.copy_source_pdf:
        pdf_embed_name = copy_source_pdf(data, sources_dir)

    note_text = render_note(data, pdf_embed_name)
    note_path = target_dir / note_name
    note_path.write_text(note_text, encoding="utf-8")

    index_path = target_dir / args.index_name
    upsert_index(index_path, note_name, data)

    print(f"NOTE={note_path}")
    print(f"INDEX={index_path}")
    print(f"PDF_COPIED={bool(pdf_embed_name)}")


if __name__ == "__main__":
    main()
