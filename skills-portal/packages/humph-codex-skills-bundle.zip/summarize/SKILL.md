---
name: summarize
description: Summarize or transcribe URLs, YouTube videos, podcasts, articles, PDFs, transcripts, and local files. Use when the user asks to summarize a link, explain what a video or article is about, extract a transcript, or get the gist of a document or local file.
---

# Summarize

Use the `summarize` CLI to summarize URLs, local files, PDFs, articles, podcasts, and YouTube links.

## Quick start

```bash
summarize "https://example.com" --model google/gemini-3-flash-preview
summarize "/path/to/file.pdf" --model google/gemini-3-flash-preview
summarize "https://youtu.be/dQw4w9WgXcQ" --youtube auto
```

## Transcript extraction

For best-effort transcript extraction from a YouTube URL:

```bash
summarize "https://youtu.be/dQw4w9WgXcQ" --youtube auto --extract-only
```

If the transcript is very large, return a concise summary first and then expand only the requested section or time range.

## Model and API keys

Set the API key for the chosen provider:

- OpenAI: `OPENAI_API_KEY`
- Anthropic: `ANTHROPIC_API_KEY`
- xAI: `XAI_API_KEY`
- Google: `GEMINI_API_KEY`
- Google aliases: `GOOGLE_GENERATIVE_AI_API_KEY`, `GOOGLE_API_KEY`

Default model:

```text
google/gemini-3-flash-preview
```

## Useful flags

- `--length short|medium|long|xl|xxl|<chars>`
- `--max-output-tokens <count>`
- `--extract-only`
- `--json`
- `--firecrawl auto|off|always`
- `--youtube auto`

## Optional services

- `FIRECRAWL_API_KEY` for blocked sites
- `APIFY_API_TOKEN` for YouTube fallback

## Optional config

Config file:

```text
~/.summarize/config.json
```

Example:

```json
{ "model": "openai/gpt-5.2" }
```
