from __future__ import annotations

import argparse
import csv
from collections import OrderedDict, defaultdict
from dataclasses import dataclass, field
from pathlib import Path


FUNCTION_ORDER = [
    "conceptual-advancement",
    "theoretical-dialogue",
    "logic-driver",
    "mechanism-or-explanation",
    "literature-comparison",
    "contribution-statement",
    "qualification-or-hedging",
    "transition-or-synthesis",
]

FUNCTION_LABELS = {
    "conceptual-advancement": "Conceptual Advancement",
    "theoretical-dialogue": "Theoretical Dialogue",
    "logic-driver": "Logic Driver",
    "mechanism-or-explanation": "Mechanism Or Explanation",
    "literature-comparison": "Literature Comparison",
    "contribution-statement": "Contribution Statement",
    "qualification-or-hedging": "Qualification Or Hedging",
    "transition-or-synthesis": "Transition Or Synthesis",
}

FUNCTION_PREFIX = {
    "conceptual-advancement": "C",
    "theoretical-dialogue": "T",
    "logic-driver": "L",
    "mechanism-or-explanation": "M",
    "literature-comparison": "R",
    "contribution-statement": "S",
    "qualification-or-hedging": "Q",
    "transition-or-synthesis": "X",
}


@dataclass
class SentenceEntry:
    article_title: str
    authors: str
    year: str
    journal: str
    quote: str
    functions: set[str] = field(default_factory=set)


def normalize(text: str) -> str:
    return " ".join((text or "").split()).strip()


def load_rows(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return [{key: normalize(value) for key, value in row.items()} for row in csv.DictReader(handle)]


def format_author_token(name: str) -> str:
    name = normalize(name)
    if "," in name:
        surname = name.split(",", 1)[0].strip()
        if surname:
            return surname
    parts = [part for part in name.split() if part]
    if not parts:
        return ""
    return parts[-1]


def format_citation(authors: str, year: str, journal: str) -> str:
    names = [name.strip() for name in authors.split(";") if name.strip()]
    surnames = [format_author_token(name) for name in names if format_author_token(name)]
    if not surnames:
        author_part = "Unknown"
    elif len(surnames) == 1:
        author_part = surnames[0]
    elif len(surnames) == 2:
        author_part = f"{surnames[0]} & {surnames[1]}"
    else:
        author_part = f"{surnames[0]} et al."

    pieces = [author_part]
    if year:
        pieces.append(year)
    if journal:
        pieces.append(journal)
    return ", ".join(pieces)


def primary_function(functions: set[str]) -> str:
    for function_name in FUNCTION_ORDER:
        if function_name in functions:
            return function_name
    return "logic-driver"


def aggregate_entries(rows: list[dict[str, str]]) -> list[SentenceEntry]:
    aggregated: OrderedDict[tuple[str, str], SentenceEntry] = OrderedDict()
    for row in rows:
        key = (normalize(row.get("article_title", "")).casefold(), normalize(row.get("quote", "")))
        if key not in aggregated:
            aggregated[key] = SentenceEntry(
                article_title=row.get("article_title", ""),
                authors=row.get("authors", ""),
                year=row.get("year", ""),
                journal=row.get("journal", ""),
                quote=row.get("quote", ""),
            )
        aggregated[key].functions.add(row.get("function", ""))
    return list(aggregated.values())


def render_markdown(rows: list[dict[str, str]]) -> str:
    entries = aggregate_entries(rows)
    grouped: dict[str, dict[str, list[SentenceEntry]]] = {
        function_name: defaultdict(list) for function_name in FUNCTION_ORDER
    }

    for entry in entries:
        group_name = primary_function(entry.functions)
        citation = format_citation(entry.authors, entry.year, entry.journal)
        grouped[group_name][citation].append(entry)

    lines: list[str] = [
        "# Sentence Bank",
        "",
        "This reading view is optimized for study rather than storage.",
        "",
        "- Sentences are grouped by a primary function so the same quote appears only once here.",
        "- If a sentence was tagged with multiple functions in the CSV, the extra labels appear as `also:`.",
        "- Index codes use short function prefixes such as `C`, `T`, `L`, `M`, `R`, `S`, `Q`, and `X`.",
        "",
    ]

    for function_name in FUNCTION_ORDER:
        section_label = FUNCTION_LABELS[function_name]
        prefix = FUNCTION_PREFIX[function_name]
        lines.append(f"## {section_label}")
        lines.append("")

        citation_groups = grouped[function_name]
        if not citation_groups:
            lines.append("_No entries yet._")
            lines.append("")
            continue

        counter = 1
        for citation in sorted(citation_groups):
            lines.append(f"### ({citation})")
            lines.append("")
            sorted_entries = sorted(
                citation_groups[citation],
                key=lambda entry: (entry.year, entry.article_title.casefold(), entry.quote.casefold()),
            )
            for entry in sorted_entries:
                index_code = f"{prefix}{counter:02d}"
                other_functions = [
                    FUNCTION_LABELS[name]
                    for name in FUNCTION_ORDER
                    if name in entry.functions and name != function_name
                ]
                suffix = f" Also: {', '.join(other_functions)}." if other_functions else ""
                lines.append(f"- `{index_code}` {entry.quote}{suffix}")
                counter += 1
            lines.append("")

    return "\n".join(lines).strip() + "\n"


def write_markdown(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Render a concise markdown reading view from the sentence-bank CSV.")
    parser.add_argument("--input", required=True, help="Path to the master CSV file.")
    parser.add_argument("--output", required=True, help="Path to the markdown output file.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    input_path = Path(args.input)
    output_path = Path(args.output)
    rows = load_rows(input_path)
    content = render_markdown(rows)
    write_markdown(output_path, content)
    print(f"Input: {input_path}")
    print(f"Output: {output_path}")
    print(f"Entries: {len(aggregate_entries(rows))}")


if __name__ == "__main__":
    main()
