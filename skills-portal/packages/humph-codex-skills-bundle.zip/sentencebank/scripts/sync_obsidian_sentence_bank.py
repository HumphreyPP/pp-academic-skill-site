from __future__ import annotations

import argparse
import csv
import re
from collections import OrderedDict
from datetime import date
from pathlib import Path

from render_sentence_bank_markdown import render_markdown, write_markdown


FIELDNAMES = [
    "article_title",
    "authors",
    "year",
    "journal",
    "function",
    "quote",
    "section_label",
    "paragraph_index",
    "zotero_key",
    "doi",
    "source_pdf",
    "evidence_note",
    "added_at",
]

DEFAULT_NOTES_DIR = (
    Path(r"D:\Mysoftware\Obsidian Vault")
    / "\u5f20\u82b1\u76c6"
    / "\u82f1\u6587\u5199\u4f5c\u65b9\u6cd5\u8bba"
    / "\u9876\u520aDiscussion\u62c6\u89e3"
)
DEFAULT_OUTPUT_CSV = Path(r"D:\codex\codexdata\output\sentencebank\data\sentence-bank.csv")
DEFAULT_MARKDOWN_VIEW = Path(r"D:\codex\codexdata\output\sentencebank\views\by-function.md")


def normalize(text: str) -> str:
    return " ".join((text or "").split()).strip()


def clean_title(title: str) -> str:
    title = normalize(title)
    title = re.sub(r"\s*-\s*Discussion\u62c6\u89e3\s*$", "", title)
    title = re.sub(r"\s*-\s*Discussion.*$", "", title)
    return title


def parse_frontmatter(text: str) -> dict[str, str]:
    if not text.startswith("---\n"):
        return {}
    end = text.find("\n---", 4)
    if end == -1:
        return {}
    metadata: dict[str, str] = {}
    for line in text[4:end].splitlines():
        if ":" not in line or line.startswith(" "):
            continue
        key, value = line.split(":", 1)
        metadata[key.strip()] = value.strip()
    return metadata


def parse_title(text: str, fallback: str) -> str:
    for line in text.splitlines():
        if line.startswith("# "):
            return clean_title(line[2:])
    return clean_title(fallback)


def find_section(text: str, heading: str) -> str:
    pattern = re.compile(rf"^##\s+{re.escape(heading)}\s*$", re.MULTILINE)
    match = pattern.search(text)
    if not match:
        return ""
    start = match.end()
    next_heading = re.search(r"^##\s+", text[start:], re.MULTILINE)
    end = start + next_heading.start() if next_heading else len(text)
    return text[start:end].strip()


def split_markdown_row(line: str) -> list[str]:
    line = line.strip()
    if line.startswith("|"):
        line = line[1:]
    if line.endswith("|"):
        line = line[:-1]

    cells: list[str] = []
    current: list[str] = []
    escaped = False
    for char in line:
        if escaped:
            current.append(char)
            escaped = False
        elif char == "\\":
            escaped = True
        elif char == "|":
            cells.append("".join(current).strip())
            current = []
        else:
            current.append(char)
    cells.append("".join(current).strip())
    return cells


def parse_sentence_extracts(section: str) -> list[dict[str, str]]:
    if not section or "_No sentence-bank extracts captured._" in section:
        return []

    table_lines = [line for line in section.splitlines() if line.strip().startswith("|")]
    if len(table_lines) < 3:
        return []

    headers = [normalize(header).casefold() for header in split_markdown_row(table_lines[0])]
    rows: list[dict[str, str]] = []
    for line in table_lines[2:]:
        cells = split_markdown_row(line)
        if len(cells) < len(headers):
            cells.extend([""] * (len(headers) - len(cells)))
        row = dict(zip(headers, cells))
        quote = normalize(row.get("quote", ""))
        function = normalize(row.get("function", ""))
        if not quote or not function:
            continue
        rows.append(
            {
                "function": function,
                "quote": quote,
                "section_label": normalize(row.get("section", "")),
                "paragraph_index": normalize(row.get("para", "")),
                "evidence_note": normalize(row.get("evidence note", "")),
            }
        )
    return rows


def dedupe_key(row: dict[str, str]) -> tuple[str, str, str]:
    return (
        normalize(row.get("article_title", "")).casefold(),
        normalize(row.get("quote", "")).casefold(),
        normalize(row.get("function", "")).casefold(),
    )


def collect_rows(notes_dir: Path) -> list[OrderedDict[str, str]]:
    rows: OrderedDict[tuple[str, str, str], OrderedDict[str, str]] = OrderedDict()
    for note_path in sorted(notes_dir.glob("*.md")):
        if note_path.name.startswith("00-"):
            continue
        text = note_path.read_text(encoding="utf-8", errors="replace")
        extracts = parse_sentence_extracts(find_section(text, "Sentence Bank Extracts"))
        if not extracts:
            continue

        metadata = parse_frontmatter(text)
        article_title = parse_title(text, note_path.stem)
        for extract in extracts:
            row = OrderedDict(
                [
                    ("article_title", article_title),
                    ("authors", metadata.get("authors", "")),
                    ("year", metadata.get("year", "")),
                    ("journal", metadata.get("journal", "")),
                    ("function", extract["function"]),
                    ("quote", extract["quote"]),
                    ("section_label", extract.get("section_label", "")),
                    ("paragraph_index", extract.get("paragraph_index", "")),
                    ("zotero_key", metadata.get("zotero_key", "")),
                    ("doi", metadata.get("doi", "")),
                    ("source_pdf", note_path.name),
                    ("evidence_note", extract.get("evidence_note", "")),
                    ("added_at", str(date.today())),
                ]
            )
            rows.setdefault(dedupe_key(row), row)
    return list(rows.values())


def write_csv(path: Path, rows: list[OrderedDict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDNAMES)
        writer.writeheader()
        writer.writerows(rows)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate the sentence-bank CSV/cache from Obsidian discussion notes."
    )
    parser.add_argument("--notes-dir", default=str(DEFAULT_NOTES_DIR), help="Folder containing Obsidian notes.")
    parser.add_argument("--output-csv", default=str(DEFAULT_OUTPUT_CSV), help="Generated sentence-bank CSV.")
    parser.add_argument("--markdown-output", default=str(DEFAULT_MARKDOWN_VIEW), help="Generated reading view.")
    parser.add_argument("--legacy-output", help="Optional second CSV path for compatibility.")
    parser.add_argument("--allow-empty", action="store_true", help="Allow overwriting outputs with an empty CSV.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    notes_dir = Path(args.notes_dir)
    output_csv = Path(args.output_csv)
    markdown_output = Path(args.markdown_output)

    rows = collect_rows(notes_dir)
    if not rows and not args.allow_empty:
        raise SystemExit(
            "No sentence-bank extracts found. Refusing to overwrite outputs; pass --allow-empty to force."
        )

    write_csv(output_csv, rows)
    write_markdown(markdown_output, render_markdown(rows))
    if args.legacy_output:
        write_csv(Path(args.legacy_output), rows)

    print(f"Notes: {notes_dir}")
    print(f"CSV: {output_csv}")
    print(f"Markdown: {markdown_output}")
    if args.legacy_output:
        print(f"Legacy CSV: {args.legacy_output}")
    print(f"Rows: {len(rows)}")


if __name__ == "__main__":
    main()
