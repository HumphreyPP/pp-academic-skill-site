from __future__ import annotations

import argparse
import csv
import re
from collections import defaultdict
from pathlib import Path


DEFAULT_NOTES_DIR = (
    Path(r"D:\Mysoftware\Obsidian Vault")
    / "\u5f20\u82b1\u76c6"
    / "\u82f1\u6587\u5199\u4f5c\u65b9\u6cd5\u8bba"
    / "\u9876\u520aDiscussion\u62c6\u89e3"
)
DEFAULT_INPUT_CSV = Path(r"D:\codex\codexdata\output\ssci-discussion-sentence-bank.csv")


def normalize(text: str) -> str:
    return " ".join((text or "").split()).strip()


def normalize_title(text: str) -> str:
    text = normalize(text).casefold()
    text = re.sub(r"\s*-\s*discussion.*$", "", text)
    text = re.sub(r"[^a-z0-9\u4e00-\u9fff]+", " ", text)
    return normalize(text)


def normalize_doi(text: str) -> str:
    text = normalize(text).casefold()
    text = text.replace("https://doi.org/", "").replace("http://doi.org/", "").replace("doi:", "")
    return text


def parse_frontmatter(text: str) -> dict[str, str]:
    if not text.startswith("---\n"):
        return {}
    end = text.find("\n---", 4)
    if end == -1:
        return {}
    metadata: dict[str, str] = {}
    for line in text[4:end].splitlines():
        if ":" not in line or line.startswith(" "):
            continue
        key, value = line.split(":", 1)
        metadata[key.strip()] = value.strip()
    return metadata


def parse_title(text: str, fallback: str) -> str:
    for line in text.splitlines():
        if line.startswith("# "):
            return line[2:]
    return fallback


def escape_cell(text: str) -> str:
    return normalize(text).replace("|", "\\|")


def render_extract_table(rows: list[dict[str, str]]) -> str:
    lines = [
        "## Sentence Bank Extracts",
        "",
        "| Function | Quote | Section | Para | Evidence note |",
        "| --- | --- | --- | --- | --- |",
    ]
    for row in rows:
        lines.append(
            "| "
            + " | ".join(
                [
                    escape_cell(row.get("function", "")),
                    escape_cell(row.get("quote", "")),
                    escape_cell(row.get("section_label", "")),
                    escape_cell(row.get("paragraph_index", "")),
                    escape_cell(row.get("evidence_note", "")),
                ]
            )
            + " |"
        )
    return "\n".join(lines)


def replace_or_insert_section(text: str, section: str) -> str:
    pattern = re.compile(r"^##\s+Sentence Bank Extracts\s*$", re.MULTILINE)
    match = pattern.search(text)
    if match:
        start = match.start()
        next_heading = re.search(r"^##\s+", text[match.end() :], re.MULTILINE)
        end = match.end() + next_heading.start() if next_heading else len(text)
        return text[:start].rstrip() + "\n\n" + section + "\n\n" + text[end:].lstrip()

    insert_pattern = re.compile(r"^##\s+For My Writing\s*$", re.MULTILINE)
    insert_match = insert_pattern.search(text)
    if insert_match:
        return text[: insert_match.start()].rstrip() + "\n\n" + section + "\n\n" + text[insert_match.start() :].lstrip()
    return text.rstrip() + "\n\n" + section + "\n"


def load_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return [dict(row) for row in csv.DictReader(handle)]


def group_csv_rows(rows: list[dict[str, str]]) -> tuple[dict[str, list[dict[str, str]]], dict[str, list[dict[str, str]]]]:
    by_doi: dict[str, list[dict[str, str]]] = defaultdict(list)
    by_title: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        if not normalize(row.get("quote", "")):
            continue
        doi = normalize_doi(row.get("doi", ""))
        title = normalize_title(row.get("article_title", ""))
        if doi:
            by_doi[doi].append(row)
        if title:
            by_title[title].append(row)
    return by_doi, by_title


def match_rows(text: str, note_path: Path, by_doi: dict[str, list[dict[str, str]]], by_title: dict[str, list[dict[str, str]]]) -> list[dict[str, str]]:
    metadata = parse_frontmatter(text)
    doi = normalize_doi(metadata.get("doi", ""))
    if doi and doi in by_doi:
        return by_doi[doi]

    title = normalize_title(parse_title(text, note_path.stem))
    if title in by_title:
        return by_title[title]

    for candidate_title, rows in by_title.items():
        if title and candidate_title and (title.startswith(candidate_title) or candidate_title.startswith(title)):
            return rows
    return []


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Backfill Sentence Bank Extracts sections into Obsidian discussion notes from an existing CSV."
    )
    parser.add_argument("--csv", default=str(DEFAULT_INPUT_CSV), help="Existing sentence-bank CSV.")
    parser.add_argument("--notes-dir", default=str(DEFAULT_NOTES_DIR), help="Folder containing Obsidian notes.")
    parser.add_argument("--dry-run", action="store_true", help="Report matches without writing notes.")
    parser.add_argument("--max-per-note", type=int, default=0, help="Optional maximum rows to write per note.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    csv_rows = load_csv(Path(args.csv))
    by_doi, by_title = group_csv_rows(csv_rows)
    notes_dir = Path(args.notes_dir)

    matched = 0
    changed = 0
    unmatched_notes = 0
    for note_path in sorted(notes_dir.glob("*.md")):
        if note_path.name.startswith("00-"):
            continue
        text = note_path.read_text(encoding="utf-8", errors="replace")
        rows = match_rows(text, note_path, by_doi, by_title)
        if not rows:
            unmatched_notes += 1
            continue
        matched += 1
        if args.max_per_note > 0:
            rows = rows[: args.max_per_note]
        section = render_extract_table(rows)
        new_text = replace_or_insert_section(text, section)
        if new_text != text:
            changed += 1
            if not args.dry_run:
                note_path.write_text(new_text, encoding="utf-8")

    print(f"CSV rows: {len(csv_rows)}")
    print(f"Notes matched: {matched}")
    print(f"Notes changed: {changed}")
    print(f"Notes unmatched: {unmatched_notes}")
    print(f"Dry run: {args.dry_run}")


if __name__ == "__main__":
    main()
