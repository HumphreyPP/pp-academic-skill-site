from __future__ import annotations

import argparse
import csv
from collections import OrderedDict
from datetime import date
from pathlib import Path

from render_sentence_bank_markdown import render_markdown, write_markdown

FIELDNAMES = [
    "article_title",
    "authors",
    "year",
    "journal",
    "function",
    "quote",
    "section_label",
    "paragraph_index",
    "zotero_key",
    "doi",
    "source_pdf",
    "evidence_note",
    "added_at",
]


def normalize(text: str) -> str:
    return " ".join((text or "").split()).strip()


def dedupe_key(row: dict[str, str]) -> tuple[str, str, str]:
    return (
        normalize(row.get("article_title", "")).casefold(),
        normalize(row.get("quote", "")),
        normalize(row.get("function", "")).casefold(),
    )


def clean_row(row: dict[str, str]) -> OrderedDict[str, str]:
    cleaned = OrderedDict()
    for field in FIELDNAMES:
        value = row.get(field, "")
        cleaned[field] = normalize(value) if field != "quote" else (value or "").strip()
    if cleaned["quote"]:
        cleaned["quote"] = " ".join(cleaned["quote"].split())
    if not cleaned["added_at"]:
        cleaned["added_at"] = str(date.today())
    return cleaned


def load_csv(path: Path) -> list[OrderedDict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        return [clean_row(row) for row in reader]


def write_csv(path: Path, rows: list[OrderedDict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDNAMES)
        writer.writeheader()
        writer.writerows(rows)


def merge_rows(master_rows: list[OrderedDict[str, str]], batch_rows: list[OrderedDict[str, str]]) -> tuple[list[OrderedDict[str, str]], int, int, int]:
    merged: OrderedDict[tuple[str, str, str], OrderedDict[str, str]] = OrderedDict()
    added = 0
    updated = 0
    skipped = 0

    for row in master_rows:
        merged[dedupe_key(row)] = row

    for incoming in batch_rows:
        key = dedupe_key(incoming)
        if key not in merged:
            merged[key] = incoming
            added += 1
            continue

        existing = merged[key]
        changed = False
        for field in FIELDNAMES:
            if not existing[field] and incoming[field]:
                existing[field] = incoming[field]
                changed = True
        if changed:
            updated += 1
        else:
            skipped += 1

    merged_rows = sorted(
        merged.values(),
        key=lambda row: (
            row["article_title"].casefold(),
            row["year"],
            row["function"].casefold(),
            row["quote"].casefold(),
        ),
    )
    return merged_rows, added, updated, skipped


def validate_batch(rows: list[OrderedDict[str, str]]) -> None:
    required = ["article_title", "authors", "year", "function", "quote"]
    valid_functions = {
        "logic-driver",
        "theoretical-dialogue",
        "conceptual-advancement",
        "mechanism-or-explanation",
        "literature-comparison",
        "contribution-statement",
        "qualification-or-hedging",
        "transition-or-synthesis",
    }
    for index, row in enumerate(rows, start=2):
        missing = [field for field in required if not row[field]]
        if missing:
            missing_text = ", ".join(missing)
            raise ValueError(f"Row {index} is missing required columns: {missing_text}")
        if row["function"] not in valid_functions:
            raise ValueError(
                f"Row {index} has invalid function '{row['function']}'. "
                f"Use one of: {', '.join(sorted(valid_functions))}"
            )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Merge a sentence-bank batch CSV into the master CSV.")
    parser.add_argument("--master", required=True, help="Path to the master CSV file.")
    parser.add_argument("--batch", required=True, help="Path to the new batch CSV file.")
    parser.add_argument(
        "--markdown-output",
        help="Optional path to refresh a concise markdown reading view after the merge.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    master_path = Path(args.master)
    batch_path = Path(args.batch)

    batch_rows = load_csv(batch_path)
    validate_batch(batch_rows)
    master_rows = load_csv(master_path)

    merged_rows, added, updated, skipped = merge_rows(master_rows, batch_rows)
    write_csv(master_path, merged_rows)

    if args.markdown_output:
        markdown_path = Path(args.markdown_output)
        write_markdown(markdown_path, render_markdown(merged_rows))

    print(f"Master: {master_path}")
    print(f"Batch: {batch_path}")
    print(f"Added: {added}")
    print(f"Updated: {updated}")
    print(f"Skipped: {skipped}")
    print(f"Total rows: {len(merged_rows)}")
    if args.markdown_output:
        print(f"Markdown: {markdown_path}")


if __name__ == "__main__":
    main()
