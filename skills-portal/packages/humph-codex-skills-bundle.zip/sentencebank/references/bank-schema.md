# Sentence Bank Schema

Use this schema for every extraction batch and for generated sentence-bank caches.

## Source Of Truth

- Preferred canonical source: `Sentence Bank Extracts` sections inside Obsidian paper notes.
- Generated cache path: `D:\codex\codexdata\output\sentencebank\data\sentence-bank.csv`
- Legacy compatibility path: `D:\codex\codexdata\output\ssci-discussion-sentence-bank.csv`
- Encoding: `utf-8-sig`
- One row per sentence-function pair

Do not manually edit generated CSV caches when the same update can be made in the Obsidian source note.

## Reading view

- Path: `D:\codex\codexdata\output\sentencebank\views\by-function.md`
- Purpose: concise study view grouped by function
- Display style: short citation such as `(Liu & Han, 2026, Public Administration)` instead of the full title
- Deduplication rule in markdown: show each sentence once under a primary function and list other labels as `also:`

## Required columns

- `article_title`: full article title
- `authors`: author string as available from Zotero or the paper metadata
- `year`: publication year
- `function`: a reusable sentence function such as `logic-driver`, `theoretical-dialogue`, or `conceptual-advancement`
- `quote`: exact original sentence from the paper

## Recommended columns

- `journal`: journal title
- `section_label`: e.g. `Discussion`, `General Discussion`, `Theoretical Implications`
- `paragraph_index`: local paragraph number within the extracted discussion section if known
- `zotero_key`: Zotero item key if available
- `doi`: DOI if available
- `source_pdf`: local PDF filename or attachment label if useful
- `evidence_note`: short reason for inclusion, especially when the function is not obvious
- `added_at`: ISO date such as `2026-04-22`

## Function guide

The three core functions below are the highest-value labels. Existing banks may also include broader labels such as `contribution-statement`, `mechanism-or-explanation`, `literature-comparison`, `qualification-or-hedging`, or `transition-or-synthesis`.

## `logic-driver`

Use when the sentence moves the reasoning of the discussion forward, for example:

- shifts from findings to interpretation
- marks contrast with prior expectations
- states a boundary condition or qualification
- explains why a result matters
- links one conceptual step to the next

## `theoretical-dialogue`

Use when the sentence explicitly engages theory or prior literature, for example:

- aligns with prior work
- challenges prior work
- reframes what earlier studies imply
- identifies a theoretical contribution or dispute

## `conceptual-advancement`

Use when the sentence changes how a concept, mechanism, research object, or condition should be understood, for example:

- "not simply X, but Y"
- new dimension of a concept
- new mechanism or interpretive process
- new boundary condition that changes the meaning of the phenomenon

## Deduplication rule

Treat rows as duplicates when `article_title` and `quote` match after whitespace normalization.
If the same sentence serves multiple functions, keep separate rows with different `function` values.
