---
name: sentencebank
description: Build, sync, and query a reusable SSCI discussion sentence bank from Obsidian discussion notes, Zotero, or user-provided papers. Use when Codex needs to extract exact sentences from discussion sections, embed sentence-bank extracts in Obsidian paper notes, regenerate CSV/Markdown caches, search mature discussion moves, or migrate older CSV sentence rows into the Obsidian-first workflow.
---

# SSCI Discussion Bank

Use this skill to maintain a cumulative bank of verbatim SSCI discussion sentences.

The current workflow is **Obsidian-first**:

- The canonical record is each paper's Obsidian note, especially its `Sentence Bank Extracts` section.
- CSV and Markdown views are generated caches for speed, deduplication, filtering, and active writing support.
- Do not manually edit the generated CSV when the sentence can be added to the Obsidian source note instead.

## Core rules

- Extract only original sentences from the paper. Do not paraphrase, compress, or translate the quoted sentence.
- Focus on discussion-like sections such as `Discussion`, `General Discussion`, `Implications`, `Theoretical Implications`, or discussion paragraphs embedded after results.
- Keep only sentences that perform at least one of these functions:
  - `logic-driver`: moves the paragraph's reasoning forward through contrast, explanation, synthesis, implication, qualification, or boundary-condition framing
  - `theoretical-dialogue`: explicitly positions the finding against prior theory, literature, or a named conceptual claim
  - `conceptual-advancement`: reframes a concept, mechanism, research object, or boundary condition
- Existing or broader banks may also use `mechanism-or-explanation`, `literature-comparison`, `contribution-statement`, `qualification-or-hedging`, and `transition-or-synthesis`; keep these only when the sentence is genuinely reusable.
- Prefer the full sentence. If a useful unit spans a semicolon but is still one sentence, keep it as one record.
- If one sentence clearly serves multiple functions, duplicate the record with different `function` values rather than inventing a hybrid label.

## Workflow

1. Use Zotero MCP or user-provided citations/files to identify the target papers.
2. Open the PDF and isolate the relevant discussion section.
3. Read for function, not just wording. Keep only sentences that actively perform one of the target functions.
4. Add selected sentences to the paper note's `Sentence Bank Extracts` section when using the Obsidian-first workflow.
5. Regenerate CSV and Markdown caches with `scripts/sync_obsidian_sentence_bank.py`.
6. Use `scripts/backfill_sentence_extracts_to_obsidian.py` when migrating older CSV rows back into notes.
7. Report how many rows were embedded, generated, updated, or skipped as duplicates.

## Output discipline

- Prefer Obsidian notes as the source of truth.
- Generate the default CSV cache at `D:\codex\codexdata\output\sentencebank\data\sentence-bank.csv`.
- Refresh the reading view at `D:\codex\codexdata\output\sentencebank\views\by-function.md` after each sync.
- Keep `D:\codex\codexdata\output\ssci-discussion-sentence-bank.csv` only as a legacy compatibility file unless the user asks to update it too.
- Store one sentence per row.
- Preserve the exact sentence in `quote`.
- Use a short, concrete `evidence_note` only when needed to explain why the sentence was selected.
- Leave fields blank rather than guessing when metadata is unavailable.
- Keep full titles in the CSV, but use short citations such as `(Liu & Han, 2026, Public Administration)` in the markdown reading view.

## Classification guidance

Read [references/bank-schema.md](references/bank-schema.md) when you need the exact field meanings or need help distinguishing `logic-driver`, `theoretical-dialogue`, and `conceptual-advancement`.

## Sync commands

Generate CSV and a Markdown reading view from Obsidian source notes:

```powershell
python .\sentencebank\scripts\sync_obsidian_sentence_bank.py --notes-dir "D:\Mysoftware\Obsidian Vault\张花盆\英文写作方法论\顶刊Discussion拆解" --output-csv .\output\sentencebank\data\sentence-bank.csv --markdown-output .\output\sentencebank\views\by-function.md
```

Backfill older CSV rows into matching Obsidian notes. Always dry-run first:

```powershell
python .\sentencebank\scripts\backfill_sentence_extracts_to_obsidian.py --csv .\output\ssci-discussion-sentence-bank.csv --dry-run
```

Use the older merge command only for standalone CSV batches or legacy imports:

```powershell
python .\sentencebank\scripts\merge_sentence_bank.py --master .\output\sentencebank\data\sentence-bank.csv --batch .\output\sentencebank\batches\new-batch.csv --markdown-output .\output\sentencebank\views\by-function.md
```
