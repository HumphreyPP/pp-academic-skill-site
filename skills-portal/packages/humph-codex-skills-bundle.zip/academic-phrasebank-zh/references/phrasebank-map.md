# Academic Phrasebank Map

Local source:

```text
references/academic-phrasebank.pdf
```

Do not copy long lists from the PDF. Use this map to locate the relevant communicative function, then adapt patterns to the user's sentence.

## Major Sections

| Function | Printed page | Approx. PDF page | Use when |
|---|---:|---:|---|
| Introducing Work | 7 | 8 | Opening a paper, establishing topic importance, stating purpose, indicating gap |
| Reviewing the Literature | 32 | 33 | Summarizing prior work, identifying themes, noting limitations |
| Describing Methods | 47 | 48 | Explaining design, sample, procedure, variables |
| Reporting Results | 57 | 58 | Reporting findings, comparisons, statistical results |
| Discussing Findings | 65 | 66 | Explaining findings, relating findings to literature, implications |
| Writing Conclusions | 73 | 74 | Restating aim, summarizing findings, contribution, limitations |

## General Functions

| Function | Printed page | Approx. PDF page | Use when |
|---|---:|---:|---|
| Being Cautious | 84 | 85 | Mechanism claims, suggestive evidence, indirect support |
| Being Critical | 88 | 89 | Evaluating literature, identifying limitations |
| Classifying and Listing | 99 | 100 | Grouping concepts, presenting dimensions |
| Comparing and Contrasting | 102 | 103 | Comparing studies, conditions, mechanisms |
| Defining Terms | 106 | 107 | Defining concepts and constructs |
| Describing Trends | 111 | 112 | Increasing/decreasing attention, trends over time |
| Describing Quantities | 113 | 114 | Proportions, degrees, extent |
| Explaining Causality | 115 | 116 | Cause, consequence, mechanism, explanation |
| Giving Examples as Support | 119 | 120 | Introducing examples |
| Indicating Shared Knowledge | 121 | 122 | Established claims, widely accepted ideas |
| Signalling Transition | 123 | 124 | Moving between paragraphs or sections |
| Writing about the Past | 127 | 128 | Historical background and prior developments |
| Writing Abstracts | 129 | 130 | Abstract structure and phrasing |
| Writing Acknowledgements | 132 | 133 | Acknowledgements |

## Notes on Academic Writing

| Topic | Printed page | Approx. PDF page | Use when |
|---|---:|---:|---|
| Academic Style | 135 | 136 | Formality, style, precision |
| British and US Spelling | 141 | 142 | Spelling consistency |
| Gender-Neutral Language | 142 | 143 | Inclusive language |
| Punctuation | 143 | 144 | Commas, semicolons, punctuation clarity |
| Using Articles | 144 | 145 | `a/an/the` |
| Sentence Structure | 146 | 147 | Sentence clarity |
| Paragraph Structure | 148 | 149 | Paragraph flow |
| Tips on the Writing Process | 149 | 150 | Revision workflow |

## Useful Lists

| Topic | Printed page | Approx. PDF page | Use when |
|---|---:|---:|---|
| Connecting Words | 152 | 153 | Connector alternatives |
| Commonly Used Verbs | 153 | 154 | Academic reporting verbs |
| Commonly Confused Words | 155 | 156 | Word choice |
| Evidence and its Collocations | 157 | 158 | Collocations around evidence |

## Function Matching Guide

- User asks “开头怎么写/引出研究”: `Introducing Work`.
- User asks “这个文献怎么对话/怎么说 existing studies”: `Reviewing the Literature`.
- User asks “suggestive evidence/可能机制怎么写”: `Being Cautious` + `Discussing Findings`.
- User asks “两个文献/两个结果怎么比较”: `Comparing and Contrasting`.
- User asks “therefore/however/in this sense 对吗”: `Signalling Transition` + `Connecting Words`.
- User asks “因果机制怎么写”: `Explaining Causality`.
- User asks “这个词常不常用/有没有搭配”: `Academic Style`, `Commonly Used Verbs`, or Zotero if discipline-specific.
