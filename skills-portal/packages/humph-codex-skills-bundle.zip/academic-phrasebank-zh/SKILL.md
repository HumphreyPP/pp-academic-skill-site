---
name: academic-phrasebank-zh
description: 用于依据 Manchester Academic Phrasebank 辅助修改英文论文表达。适用于用户询问某个英文表达是否自然、是否常用、是否学术、是否中式英语，或要求为 introduction、literature review、methods、results、discussion、conclusion 等章节提供更地道的 academic phrase、连接表达、谨慎表达、因果表达、比较表达、批判表达和段落过渡。该 skill 只参考用户本地 Academic Phrasebank PDF 的相关小范围内容，不复制或输出大段短语库。
---

# Academic Phrasebank Zh

## 定位

本 skill 专门处理“表达功能”和“句式选择”，不是全文逻辑审查工具。

- 如果用户问“这句话顺不顺、常不常用、怎么更学术、有没有替代表达”，使用本 skill。
- 如果用户问“这段论证逻辑是否成立、贡献是否清楚、段落结构是否合理”，优先使用 `writing-logic-check-zh`。
- 如果两者都需要，先用 `writing-logic-check-zh` 判断逻辑关系，再用本 skill 优化表达。

## 版权和使用边界

用户提供的本地 PDF：

```text
references/academic-phrasebank.pdf
```

使用规则：

- 不要把 PDF 全文或长篇短语列表复制到回答或 skill 文件中。
- 只按用户当前表达的 communicative function 小范围参考相关页面。
- 可以引用极短片段作为“句式证据”，但默认用转述和句式模式说明。
- 输出时重在给用户可用的改写句，而不是复刻 Phrasebank 列表。

## 工作流

1. 判断用户要实现的表达功能：
   - 引出研究背景或重要性
   - 说明已有研究
   - 指出 gap / problem / controversy
   - 陈述研究目的
   - 比较和对照
   - 解释因果
   - 谨慎表达机制或推断
   - 批判文献
   - 报告结果
   - 讨论发现
   - 写结论或贡献
   - 段落过渡
2. 根据功能读取 `references/phrasebank-map.md`，定位 PDF 相关章节。
3. 必要时运行 `scripts/extract_phrasebank_section.py` 抽取相关页面，且只读取当前任务需要的页段。
4. 判断用户原表达的问题：
   - 是否搭配自然
   - 是否语义过强或过弱
   - 是否连接词不匹配
   - 是否有中式英语
   - 是否使用了生硬抽象名词
   - 是否不符合章节功能
5. 给出 2-4 个可替代表达，并标注适用语境。
6. 推荐一个最适合当前论文语境的版本，并解释为什么。

## 输出格式

默认中文解释，英文句子保留原文。

```text
判断
这个表达可以/不建议优先用，原因是...

Phrasebank 对应功能
它属于 [function]，应参考 [section]。

可用表达
1. ...
2. ...
3. ...

最推荐版本
...

为什么
...
```

如果用户要求“找依据”，要说明：

- Phrasebank 支持的是“表达功能和常见句式”，不是实证文献证据。
- 若用户要期刊原句或学科文献依据，继续只查 Zotero/本地库。

## 常用判断口径

- `This has motivated...`：语法可行，但若用户要求“常用依据”，应查 Phrasebank 是否有类似功能句式；通常可换为更明确的 `These concerns have led to...`、`This issue has received...`、`Scholars have increasingly...`，具体选择取决于主语。
- `has prompted scholars to...`：自然，但略带“外部问题推动研究者行动”的语气。适合前文确实提出 concern/problem 后使用。
- `a growing body/stream of research...`：适合概括文献群，但后文 citation 必须真的支持该文献群。
- `administrative discretion`：这是学科概念，不属于 Phrasebank 的通用表达；应结合 PA/Zotero 文献判断。
