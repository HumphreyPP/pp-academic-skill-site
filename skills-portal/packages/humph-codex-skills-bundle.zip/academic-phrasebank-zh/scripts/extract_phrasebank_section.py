"""Extract a small page range from the user's local Academic Phrasebank PDF.

Usage:
  python extract_phrasebank_section.py --start 84 --end 86

The arguments use printed page numbers from the Phrasebank contents. The script
adds the observed +1 offset to map printed pages to PDF pages.
"""

from __future__ import annotations

import argparse
from pathlib import Path

from pypdf import PdfReader


DEFAULT_PDF = Path(__file__).resolve().parents[1] / "references" / "academic-phrasebank.pdf"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pdf", default=str(DEFAULT_PDF))
    parser.add_argument("--start", type=int, required=True, help="Printed start page")
    parser.add_argument("--end", type=int, required=True, help="Printed end page")
    args = parser.parse_args()

    pdf_path = Path(args.pdf)
    if not pdf_path.exists():
        raise SystemExit(f"PDF not found: {pdf_path}")

    reader = PdfReader(str(pdf_path))
    for printed_page in range(args.start, args.end + 1):
        pdf_index = printed_page  # printed page 7 is PDF page 8, zero-index 7
        if pdf_index < 0 or pdf_index >= len(reader.pages):
            continue
        text = reader.pages[pdf_index].extract_text() or ""
        print(f"\n--- Printed page {printed_page} ---\n")
        print(text.strip())


if __name__ == "__main__":
    main()
