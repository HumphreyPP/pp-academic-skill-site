---
name: writing-logic-check-zh
description: 用于审查和改写英文研究论文的写作逻辑。适用于检查 introduction、literature review、theory、hypotheses、results prose、discussion、conclusion 或单个段落是否具有清楚的问题意识、论证链条、段落功能、句间衔接、claim-reason-evidence-warrant 关系、读者导向和学术英文表达；也可基于 Booth、Wallwork、Belcher、范逸洲等写作书的原则进行逐点诊断、解释为什么要改、给出低中式英语的改写版本。
---

# Writing Logic Check Zh

## 使用场景

当用户要求“检查写作逻辑”“帮我看这段顺不顺”“像顶刊一样审查”“为什么这么写”“帮我改得更清楚”“检查中式英语和连接词”“基于写作书给规则”时，使用本 skill。

本 skill 负责通用写作逻辑审查。若用户明确要求检查 Introduction 或 Discussion 的理论贡献，可同时参考 `introduction-check-zh` 或 `discussion-check-zh`，但不要把本 skill 变成只服务某一章节的模板。

不要默认绑定用户已有的算法治理、公共管理或 AI 主题论文。那些材料可以作为例子帮助理解用户偏好，但团队共享时必须先抽象为通用写作问题：问题意识、论证链条、证据支撑、段落功能、读者导向和英文表达。

## 核心原则

综合以下写作书的原则，但不要长篇引用原文：

- Booth 等：研究写作要让读者看到 topic -> question -> problem -> response -> so what；论证要有 claim、reason、evidence、warrant，并回应潜在异议。
- Wallwork：英文论文要以读者可读性为中心；句子应清楚呈现 old-to-new 信息流、关键词一致、动作清楚、歧义少、复杂信息后置。
- 范逸洲等：中文作者写英文论文要有读者意识，给读者“递梯子”；常用 Old-to-New、Problem-Solution、Process 等行文模型；连接词、summary words 和适当重复要服务逻辑，不要机械堆砌。
- Belcher：论文不是资料堆积，而是面向目标期刊读者的可发表论证；revision 应围绕 central argument、article structure、reader response 和 journal fit 展开。

更多细则按需读取：

- `references/source-principles.md`：来源原则的整理。
- `references/logic-rubric.md`：审查维度和评分规则。
- `references/rewrite-patterns.md`：常见逻辑改写句式和禁用表达。

## 默认工作流

1. 判断文本类型：Introduction、文献综述、理论假设、Discussion、段落、句子，或混合文本。
2. 先给一句总体判断：逻辑是否成立、最大问题是什么、是否需要大改。
3. 分点审查，不要一整段笼统点评。至少覆盖：
   - 问题意识：读者是否知道为什么要读。
   - 论证链条：claim、reason、evidence、warrant 是否齐全。
   - 段落功能：每段是否只做一件主要事情。
   - 句间衔接：旧信息是否自然引出新信息。
   - 文献使用：citation 是否支撑前面的具体 claim。
   - 英文表达：是否有中式英语、连接词误用、生硬词、重复和不必要抽象名词。
4. 对每个问题说明“为什么这是问题”，再给“可用修改”。
5. 如用户需要，给出一版完整改写；默认尽量保留用户原意和已有术语，不做过度改写。
6. 若用户要求“严格按 PA 顶刊标准”，提高审查强度，重点检查逻辑闭环、贡献对象、概念推进、限定语和证据-结论匹配。

## 输出格式

默认用中文讲解，可保留英文原句和改写句。

建议结构：

```text
总体判断
逐点审查
可用改写
为什么这样改
下一步建议
```

如果文本很短，压缩为：

```text
这句基本可以/不太稳。问题在于...
建议改成...
原因是...
```

## 审查时必须注意

- 不要只说“更自然”“更学术”，要解释自然在哪里、逻辑关系是什么。
- 不要把所有句子都改成模板化表达；保留作者的思想密度。
- 不要把弱证据写成强结论。对边缘显著、机制推断、文献间接支持，要使用 may、suggest、can help explain 等限定。
- 不要用少见或生造概念包装简单逻辑。
- 不要机械建议 `however/therefore/moreover`；每个连接词必须说明它连接的是转折、因果、递进、限定还是对照。
- 如果用户要求找文献或佐证表达，默认只查用户 Zotero/本地库，不联网；除非用户明确要求联网。
- 如果用户要求纠正英文表达、判断某个短语是否自然/常用/学术，优先参考 `academic-phrasebank-zh` 的流程和用户本地 `academic-phrasebank.pdf`；但不要复制或输出 Phrasebank 的长篇短语列表。
