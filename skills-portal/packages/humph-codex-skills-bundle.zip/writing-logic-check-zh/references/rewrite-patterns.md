# Rewrite Patterns for Academic Writing Logic

## 建立研究问题

```text
Recent work has shown that [known finding], but it remains less clear [unresolved issue].
This distinction matters because [theoretical/practical reason].
```

```text
Existing research has focused primarily on [X]. Less is known about [Y], even though [Y] is important because [reason].
```

```text
This literature has clarified [X], but it leaves open how/whether/when [Y].
```

## 从背景过渡到研究问题

```text
These developments raise an important question: [research question].
```

```text
This shift makes it important to understand how [actor] evaluates [phenomenon].
```

```text
If [condition is true], then [unresolved issue] becomes central to understanding [larger phenomenon].
```

## 解释机制

```text
One plausible explanation is that [mechanism].
```

```text
This pattern suggests that [observed result] may reflect [underlying process].
```

```text
The logic is that [condition] changes how citizens interpret [action/object].
```

```text
Under these conditions, [action] is more likely to be interpreted as [meaning], thereby [consequence].
```

## 文献对话

```text
This interpretation builds on [Author]'s finding that [prior finding].
```

```text
Our findings add a further condition: [new condition].
```

```text
This helps explain why our findings differ from [Author]: [difference in setting/mechanism/outcome].
```

```text
Whereas prior research emphasizes [X], our findings show that [Y] also matters.
```

## 贡献表达

```text
These findings extend research on [field] beyond [existing focus] to [new focus].
```

```text
We refine this view by showing that [accepted claim] depends on [boundary condition].
```

```text
The contribution is not simply to add another variable, but to show how [factor] changes the interpretation of [core phenomenon].
```

```text
This study shifts attention from [old question] to [new question].
```

## 连接词替换

如果不是严格因果，不要用 `therefore`，可用：

```text
This has motivated...
Against this backdrop,...
This makes it important to examine...
```

如果不是强转折，不要用 `however`，可用：

```text
At the same time,...
This literature leaves less clear...
Yet this work has paid less attention to...
```

如果需要比较两篇文献：

```text
The difference lies not in [shared element], but in [key distinction].
```

```text
What differs is whether [condition] makes [action] appear [interpretation].
```

## 常见弱表达替换

- `has important theoretical and practical significance` -> `matters because [specific reason]`
- `fills the gap` -> `addresses this gap by [specific action]`
- `enriches the literature` -> `extends/refines/challenges [specific literature] by showing [specific contribution]`
- `under the background of` -> `Against this backdrop` / `In this context`
- `make a deep study of` -> `examines`
- `bring into the discussion` -> `incorporates [factor] into explanations of [phenomenon]`
- `very few scholars have studied` -> `less is known about [specific issue]`

## 逐句改写时的解释模板

```text
原句的问题不是语法，而是逻辑对象不稳定：前半句讲 [X]，后半句突然转到 [Y]。建议把 [shared object] 放到主语位置，让句子围绕同一个对象推进。
```

```text
这里需要的不是更高级的词，而是更明确的 warrant。读者会问：为什么 [evidence] 能推出 [claim]？建议补一句 [warrant sentence]。
```

```text
这个连接词不稳，因为前后不是因果/转折/递进关系。建议改成 [alternative]，把关系写成 [actual relation]。
```

