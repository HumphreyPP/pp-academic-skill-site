---
name: introduction-check-zh
description: 用于检查、诊断、改写英文研究论文 Introduction，也可拆解已发表顶刊论文的 Introduction 谋篇布局并生成 Obsidian 学习笔记。适用于社会科学、公共管理、管理学、教育学、传播学、法学等领域的实证论文、理论论文和综述论文；判断引言是否有清楚的问题意识、文献推进、研究缺口、研究问题、方法入口、贡献预告和英文表达，并提供逐段诊断、修改建议、可替换英文句子、顶刊写法拆解和 md 笔记。
---

# Introduction Check Zh

## 使用场景

当用户要求检查、重写、打磨或学习论文 Introduction 时使用本 skill。它是通用的 Introduction 写作与拆解工具，不默认绑定任何特定主题。用户的具体论文可以作为例子，但检查标准应适用于大多数英文研究论文。

团队共享时，不要把用户已有的算法治理、公共管理或 AI 论文当作默认模板；只迁移其中的写作动作，例如问题链、文献推进、gap 重要性、研究问题收束和贡献预告。

本 skill 有两种主要模式：

1. **检查/改写模式**：用于检查用户自己的 Introduction，判断问题意识、文献推进、gap、RQ、方法入口、贡献预告和英文表达，并给出修改稿。
2. **顶刊拆解模式**：用于拆解已发表论文的 Introduction，学习其谋篇布局、move 结构、gap 写法、贡献铺垫和可迁移句式；必要时生成 Obsidian md 学习笔记。

适用任务：

- 判断 Introduction 是否只是背景综述，而没有提出真正的研究问题。
- 检查从现象、重要性、已有研究、缺口、研究问题、研究路径到贡献预告的逻辑链。
- 检查文献是否与本文问题意识融合，而不是“文献和研究两张皮”。
- 检查 gap 是否只是 `few studies`，还是说明了为什么这个未解决问题重要。
- 检查研究问题是否能统领 hypotheses、analysis、method、discussion。
- 检查贡献是否是理论推进，而不是结果复述。
- 拆解顶刊 Introduction 的段落功能、逻辑推进、缺口策略和贡献铺垫。
- 为一篇或多篇论文生成 Obsidian 学习笔记。

## 核心判断

Introduction 不是“介绍主题”，而是“说服读者这篇文章为什么必须存在”。它通常要完成四件事：

1. 让读者知道这个问题为什么值得关心。
2. 让读者知道已有研究已经解释了什么。
3. 让读者知道已有研究还没有解释什么，以及这个缺口为什么重要。
4. 让读者知道本文如何回应这个缺口，并预告后文贡献。

检查或拆解时默认使用“读者问题链”：

```text
What is happening?
Why does it matter?
What has the literature already shown?
What remains unclear?
Why does that gap matter?
What does this study examine?
How does the approach answer the question?
What does this study contribute?
```

如果其中任何一环缺失，Introduction 就会显得没有抓手。

## 模式一：检查/改写用户自己的 Introduction

### 1. 先还原 Introduction Promise

在检查正文前，先用一句话概括这篇文章的引言承诺：

```text
This paper examines [phenomenon/problem] because existing research has [shown X] but has not sufficiently explained [Y], which matters because [reason]. By examining [design/data/case/mechanism], the study contributes to [theoretical conversation].
```

如果无法写出这句话，说明 Introduction 的问题意识还不够集中。

### 2. 画出段落功能图

逐段判断每段承担的功能。优先使用以下通用结构，但不要机械套模板：

1. **现象或主题入口**：说明研究对象是什么，不要写成宏大背景。
2. **重要性建立**：说明该问题对实践、理论、方法或目标读者为什么重要。
3. **已有研究主线**：概括已有研究的核心发现，而不是堆文献。
4. **研究缺口或张力**：说明尚未解释的是具体问题、机制、边界条件、概念差异、证据冲突或视角缺失。
5. **缺口重要性**：回答 `So what?`，说明为什么这个缺口值得研究。
6. **研究问题或研究目标**：提出本文要回答的问题。
7. **研究路径或方法入口**：简洁说明研究设计、数据、案例、材料或理论路径如何回应问题。
8. **发现与贡献预告**：预告主要发现和理论贡献，但不要把 Discussion 提前完整写完。

### 3. 检查文献是否真正推进问题

每个文献段都要回答三个问题：

- 这组文献已经告诉我们什么？
- 它还没有解释什么？
- 这个未解释之处为什么会影响本文研究对象或理论理解？

不接受这类弱缺口：

```text
Few studies have examined X.
Little is known about Y.
There is limited research on Z.
```

除非后面立即说明：为什么这个缺口在理论上、经验上、方法上或实践上重要。

更好的缺口写法：

```text
This work has clarified [X], but it leaves less clear [Y], a distinction that matters because [reason].
```

### 4. 检查研究问题是否统领全文

研究问题必须能统领后文。检查：

- RQ 是否直接包含核心因变量、解释对象或分析对象。
- RQ 是否暗含或明示主要解释变量、机制、案例、材料或理论张力。
- 后文关键变量、案例、方法、数据或调节条件是否在 RQ 后自然出现，而不是突然出现。
- RQ 的范围是否刚好等于本文能回答的范围。

### 5. 检查贡献预告是否和后文对齐

Introduction 结尾的贡献预告要和后文 Discussion / Conclusion 的理论对话相互照应。检查：

- 贡献对象是否明确：推进的是哪一组文献、理论、方法或经验研究。
- 贡献形式是否明确：是 refinement、extension、boundary condition、mechanism、reconciliation、new evidence 还是 new framework。
- 贡献是否不只是结果复述。
- 后文是否真正回到这些贡献。

Introduction 只需要“开门”，Discussion 才负责“展开理论对话”。不要在 Introduction 里提前写完整机制解释。

## 模式二：顶刊 Introduction 拆解模式

当用户要求“拆解顶刊 Introduction”“学习发表论文的引言写法”“分析这篇文章 introduction 怎么谋篇布局”时，进入此模式。

拆解目标不是总结论文内容，而是学习作者如何写 Introduction。重点分析：

- 作者如何开头，并快速进入研究问题。
- 作者如何组织已有文献，而不是堆文献。
- 作者如何构造 gap，以及 gap 属于哪一种类型。
- 作者如何解释 gap 的重要性。
- 作者如何提出 RQ / aim / argument。
- 作者如何引入理论、案例、变量、方法或数据。
- 作者如何在 Introduction 里预告贡献。
- 哪些写法可以迁移到用户自己的论文写作。

处理一篇论文时，输出一份拆解；处理多篇论文时，对每篇分别拆解，并在最后比较它们的写法差异。

详细流程见 `references/deconstruction-mode.md`。

## 模式三：Obsidian 拆解笔记生成

当用户要求把拆解结果“生成 md”“放进 Obsidian”“做成笔记”“收集起来”时，生成 Markdown 笔记。

默认 Obsidian 文件夹：

```text
D:\Mysoftware\Obsidian Vault\张花盆\英文写作方法论\顶刊Introduction拆解
```

规则：

- 如果文件夹不存在，创建它。
- 一篇论文通常生成一个 md 文件。
- 多篇论文可以按用户要求生成多个 md，或生成一个 batch 综合笔记；若用户没有说明，默认每篇一个 md，并额外生成或更新一个索引文件。
- 每篇笔记必须包含 APA 格式 citation。
- 不要大段复制原文。可以提供极短原句用于说明，但主要用 paraphrase 和可迁移句式。
- 文件名使用 `年份-第一作者-短标题-Introduction拆解.md`，移除 Windows 非法字符。

详细模板见 `references/deconstruction-mode.md`。

## 英文表达检查

优先使用清楚、平实、目标期刊常见的学术英语。避免：

- `With the rapid development of...`
- `Nowadays...`
- `under the background of...`
- `has important theoretical and practical significance`
- `fills the gap`
- `this paper enriches...`
- 连续堆叠 `therefore`, `however`, `in addition`, `moreover`。

优先使用：

```text
Recent work has shown that...
This literature has clarified..., but it leaves less clear...
This distinction matters because...
We focus on...
This study examines...
These findings contribute in three ways.
```

## 输出格式

用户要求“检查”时：

1. **总体判断**：说明引言是否有抓手，最大问题是什么。
2. **段落功能图**：逐段标明每段功能和是否完成。
3. **关键逻辑问题**：按严重程度列出，不要只改语言。
4. **逐点修改建议**：对每个问题给出可替代英文，并解释为什么这样改。
5. **压缩或重写版本**：如果用户需要，提供可直接替换的英文版本。

用户要求“重写”时：

1. 先重建问题链。
2. 再确定每段功能。
3. 再写英文稿。
4. 最后用中文解释这版如何和后文 research question / hypotheses / analysis / discussion 对齐。

用户要求“拆解已发表论文”时：

1. 给出 APA citation。
2. 先用一句话概括 Introduction 的总体写作策略。
3. 逐段列出 paragraph map。
4. 分析 gap 类型与 gap 建构方式。
5. 分析研究问题和贡献铺垫。
6. 提炼可迁移写法。
7. 给出对用户写作的启发。
8. 如果用户要求，生成 Obsidian md 笔记。

## 需要时读取的参考文件

- `references/diagnostic-rubric.md`：用于严格打分和逐项诊断。
- `references/rewrite-patterns.md`：用于生成可替换句式和段落模板。
- `references/deconstruction-mode.md`：用于拆解已发表论文 Introduction 和生成 Obsidian 笔记。
- `references/source-notes.md`：本 skill 的写作依据和来源笔记。
