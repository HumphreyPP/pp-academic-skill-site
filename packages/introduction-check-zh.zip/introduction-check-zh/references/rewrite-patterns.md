# Introduction Rewrite Patterns

这些不是固定模板，而是检查和改写时可使用的句法资源。优先选择最自然、最贴合用户文章的一种。

## 1. 现实入口

```text
[Phenomenon] has become increasingly common in [setting].
```

```text
[Actors] increasingly rely on [tool/practice] to [specific action].
```

```text
[Setting] provides an important context for examining [problem] because [reason].
```

避免：

```text
With the rapid development of...
Nowadays...
Under the background of...
```

## 2. 重要性

```text
This matters because...
```

```text
The issue is consequential for [field/theory/practice] because...
```

```text
Understanding this process is important for explaining...
```

```text
This setting is theoretically useful because...
```

## 3. 已有研究主线

```text
Existing research has mainly examined...
```

```text
This literature has shown that...
```

```text
Recent studies suggest that...
```

```text
One line of research focuses on..., while another examines...
```

```text
Prior work has developed two explanations for...
```

## 4. 从已有研究转向本文问题

```text
Yet [broader concept] is not a single arrangement.
```

```text
This distinction matters because [reason].
```

```text
The central question is therefore not only whether [X], but how [Y].
```

```text
This work tells us less about [specific missing element].
```

```text
This comparison leaves open how [process/relationship] operates in [setting].
```

## 5. 强缺口

```text
Although prior work has shown [X], it remains less clear [Y].
```

```text
This literature has clarified [X], but it leaves [Y] undertheorized.
```

```text
What remains unclear is whether [X] changes how [actors] evaluate [Y].
```

```text
This gap is consequential because [reason tied to theory/design/outcome].
```

避免：

```text
Few studies have examined...
```

如果必须用，后面补上：

```text
This omission matters because...
```

## 6. 研究问题

```text
This study asks: How does [X] shape [Y] in [context]?
```

```text
We examine whether [X] affects [Y], and whether this relationship depends on [Z].
```

```text
The central question is how [actors] interpret [action/process] under [condition].
```

```text
This article investigates why [phenomenon] occurs and when it becomes more likely.
```

## 7. 引入理论、变量、案例或方法对象

```text
[Theory] provides a useful lens for examining this question because...
```

```text
[Moderator/context] may matter because it changes the meaning of [relationship/action].
```

```text
[Case/setting] is well suited to this question because...
```

```text
[Method/data] allows us to observe [relationship/process] that prior work has left unclear.
```

```text
This setting makes the problem visible because...
```

## 8. 研究设计预告

```text
To examine this question, we conduct...
```

```text
We use [data/design] to test...
```

```text
The design varies [factor 1], [factor 2], and [factor 3].
```

```text
This approach allows us to distinguish between [explanation A] and [explanation B].
```

## 9. 发现预告

```text
The results show that...
```

```text
We find that...
```

```text
Evidence for [secondary finding] is more suggestive.
```

```text
These findings suggest that...
```

## 10. 贡献预告

```text
This study contributes in three ways.
```

```text
First, it refines [literature] by showing that...
```

```text
Second, it extends [literature] beyond [old focus] to [new focus].
```

```text
Third, it identifies [condition/mechanism] that shapes...
```

```text
Together, these findings show that...
```

## 11. 压缩句

原句：

```text
There are many studies about X, and these studies have examined A, B, and C, but there are few studies about Y.
```

可改：

```text
Research on X has clarified A, B, and C, but it leaves Y less clear.
```

原句：

```text
This study fills this gap and has important theoretical significance.
```

可改：

```text
By examining Y, this study shows how [theory] operates under [condition].
```

