# Top-Journal Introduction Deconstruction Mode

用于拆解已发表论文的 Introduction，并在需要时生成 Obsidian Markdown 学习笔记。

## 1. 先确认材料

用户可能提供：

- PDF 文件。
- DOCX 文件。
- Zotero 条目、标题、作者、DOI 或文件夹。
- 直接粘贴的 Introduction 文本。

优先读取论文原文 Introduction。如果只能读取全文而不能自动识别 Introduction，按以下边界判断：

```text
Start: Introduction / 1 Introduction / opening section after abstract
End: next main heading, such as Theory, Literature Review, Background, Methods, Hypotheses, Related Work
```

如果用户给多篇论文：

- 分别拆解每篇。
- 最后增加一个 cross-paper comparison，比较它们的开头策略、gap 类型、贡献铺垫和可迁移写法。

## 2. 元数据与 APA Citation

尽量从 Zotero metadata、PDF metadata 或论文首页获取：

- Authors
- Year
- Title
- Journal
- Volume(issue)
- Pages
- DOI

APA 7 基本格式：

```text
Author, A. A., Author, B. B., & Author, C. C. (Year). Title of article. Journal Title, volume(issue), page-page. https://doi.org/xxxxx
```

如果信息缺失，在笔记里标注：

```text
APA citation: [metadata incomplete - verify manually]
```

不要编造 DOI、页码或期刊信息。

## 3. 拆解维度

### A. Overall Strategy

用 2-4 句中文说明这篇 Introduction 的总体谋篇：

- 从什么现象进入？
- 先对话哪组文献？
- gap 是怎么被制造出来的？
- 研究问题和贡献是如何出现的？

### B. Paragraph Map

逐段拆解，使用表格：

```markdown
## 原文全文对照

> 如果是用户自己的 manuscript，在这里或表格中保留完整原文段落。
> 如果是已发表论文，不把 Introduction 全文抽成文本复制到笔记里；改为嵌入或链接用户本地 PDF，让用户在 Obsidian 中直接查看原文全文。

![[_sources/YYYY-Author-ShortTitle.pdf]]

| 段落 | 原文对照 | 功能 | 功能拆解 | 学习提示 |
|---|---|---|---|---|
| P1 | 用户自有文本：完整原文段落。已发表论文：对应嵌入 PDF 中的 Introduction P1，可加一句忠实转述帮助定位。 | Phenomenon / Importance | ... | ... |
```

原文对照的处理规则：

- 如果材料是用户自己的 manuscript、用户明确提供的待修改文本，或不受版权限制的文本，可以在“原文对照”列放完整段落，便于逐句学习。
- 如果材料是已发表论文、书籍章节或其他受版权保护来源，不要把 Introduction 全文抽成文本复制进笔记。优先把用户本地 PDF 复制到 Obsidian 当前拆解文件夹的 `_sources/` 子文件夹，并在笔记中用 Obsidian PDF embed 呈现全文，例如 `![[_sources/2026-Liu-ShortTitle.pdf]]`。
- 如果不能复制 PDF 到 Obsidian vault，就放本地 PDF 链接，并在表格中用 Introduction 段落编号和忠实转述帮助用户回到原文。
- 对已发表论文，“原文对照”列推荐写法是：`嵌入 PDF 中的 Intro P3：作者从 A 文献转向 B 文献，指出现有研究主要关注 X，而 Y 被忽视。` 如果用户正在研究算法治理，可以把 A/B/X/Y 具体化为 AI accountability、drifting actors、forum drifting 等。
- 如果用户特别要求“看原文全文”，不要把已发表论文全文粘贴为纯文本；应改用本地 PDF 嵌入/链接。这样用户能对照原文全文，笔记也不会变成版权文本搬运。
- “为什么有效”和“可学习写法”不要拆成两列，默认合并为“学习提示”。这一列只保留最值得迁移的一条写法或判断。

功能标签可选：

- Phenomenon
- Importance
- Literature line
- Literature tension
- Gap
- Why gap matters
- Research question
- Theory / mechanism setup
- Context / case justification
- Method / data preview
- Findings preview
- Contribution preview
- Roadmap

### C. Gap Strategy

判断 gap 类型：

- Empirical gap：某对象、场景或样本尚未被研究。
- Conceptual gap：已有概念太粗，需要拆分或重新界定。
- Mechanism gap：知道关系存在，但不知道为什么。
- Boundary-condition gap：不知道关系何时更强、更弱或反转。
- Tension gap：已有研究结论冲突。
- Perspective gap：已有研究看 A 的视角，本文转向 B 的视角。
- Theoretical-transfer gap：旧理论进入新场景后含义不清。

说明作者是否回答了：

```text
What is missing?
Why does it matter?
Why can this study address it?
```

### D. Literature Organization

分析作者如何组织文献：

- 按主题分组？
- 按理论传统分组？
- 按争议或张力分组？
- 按时间推进？
- 按 old-to-new / general-to-specific / problem-solution 推进？

指出它是否避免了文献罗列，以及如何避免。

### E. Contribution Setup

分析 Introduction 如何提前铺垫贡献：

- 贡献对象是什么？
- 贡献形式是什么：refine, extend, identify mechanism, identify boundary condition, reconcile mixed findings, offer new evidence, build framework？
- 贡献是否和 gap 对应？
- 贡献是否和后文 Discussion 可能形成呼应？

### F. Reusable Writing Moves

不要大段复制原文。将作者写法转化为可迁移句式：

```text
The author first establishes [phenomenon], then narrows the focus to [specific problem].
```

```text
The gap is not framed as "few studies," but as a mismatch between [existing focus] and [theoretical need].
```

```text
The contribution is framed as moving beyond [old focus] to [new focus].
```

如果确实需要引用原文，只引用极短短语，并控制在版权限制内。

### G. Lessons For My Writing

最后用 3-6 条中文总结：

- 这篇 Introduction 最值得学的地方。
- 用户写自己论文时可以迁移什么。
- 哪些写法不一定适合用户，需要谨慎。

## 4. Obsidian Markdown Note Template

默认保存文件夹：

```text
D:\Mysoftware\Obsidian Vault\张花盆\英文写作方法论\顶刊Introduction拆解
```

文件名：

```text
YYYY-FirstAuthor-ShortTitle-Introduction拆解.md
```

Markdown 模板：

```markdown
---
type: introduction-deconstruction
created: YYYY-MM-DD
source: published-paper
authors: 
year: 
journal: 
doi: 
tags:
  - introduction写作
  - 顶刊拆解
---

# [Title] - Introduction 拆解

## APA Citation

Author, A. A. (Year). Title. Journal, volume(issue), pages. DOI

## 一句话总览

这篇 Introduction 的核心写作策略是：...

## Introduction Promise

```text
This paper examines [X] because existing research has shown [A] but has not explained [B], which matters because [C].
```

## 段落功能图

## 原文全文对照

> 用户自有文本可放完整原文段落。已发表论文请嵌入或链接用户本地 PDF，不要把 Introduction 全文抽成文本复制进笔记。

![[_sources/YYYY-Author-ShortTitle.pdf]]

## 段落功能图

| 段落 | 原文对照 | 功能 | 功能拆解 | 学习提示 |
|---|---|---|---|---|
| P1 | 用户自有文本：完整原文段落。已发表论文：对应上方 PDF 的 Intro P1，并用一句话转述原文内容。 |  |  |  |

## Gap 策略

- Gap 类型：
- 作者如何写出 gap：
- 为什么这个 gap 成立：
- 它如何导向研究问题：

## 文献组织方式

- 文献是如何分组的：
- 是否有 old-to-new / general-to-specific / problem-solution：
- 是否避免文献罗列：

## 研究问题与贡献铺垫

- RQ / aim 如何出现：
- 方法或案例如何被引入：
- 贡献对象：
- 贡献形式：

## 可迁移写法

1. ...
2. ...
3. ...

## 对我写作的启发

1. ...
2. ...
3. ...

## 需要谨慎的地方

1. ...
```

## 5. Batch Index

如果用户一次拆解多篇论文，或文件夹中已有多篇笔记，维护一个索引文件：

```text
00-Introduction拆解索引.md
```

索引格式：

```markdown
# 顶刊 Introduction 拆解索引

| 日期 | 论文 | 期刊 | Gap 类型 | 最值得学的写法 | 笔记 |
|---|---|---|---|---|---|
| YYYY-MM-DD | Author (Year) | Journal | Mechanism gap | ... | [[note name]] |
```
