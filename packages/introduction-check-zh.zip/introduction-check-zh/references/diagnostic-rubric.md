# Introduction Diagnostic Rubric

用 0-5 分检查每项。4 分以上才接近 SSCI / international journal Introduction 的要求。

## 1. Problem Orientation

- 5 分：开头快速进入研究对象，并说明为什么这个问题对目标读者重要。
- 3 分：有研究对象，但重要性主要靠宏大背景或常识判断支撑。
- 1 分：只是介绍时代背景，读者看不出本文为什么必须存在。

检查问题：

- 第一段是否已经把读者带到本文问题，而不是停留在大背景？
- 是否回答了 Booth 式的 `So what?`
- 是否避免了 `X is rapidly developing` 这类空泛开头？例如算法治理论文中的 `AI is rapidly developing`。

## 2. Literature Movement

- 5 分：已有研究被组织成清楚的理论路线，读者能看到从已有研究到本文问题的推进。
- 3 分：文献相关，但主要是并列罗列。
- 1 分：文献像摘要集合，和本文研究问题没有形成推进关系。

检查问题：

- 每组文献是否有一句概括性结论？
- 是否说明这些文献已经解决了什么？
- 是否说明它们没有解决什么？

## 3. Gap Quality

- 5 分：缺口具体、重要，并且直接导向本文研究设计或理论推进。
- 3 分：缺口具体，但重要性解释不足。
- 1 分：只是说 `few studies` 或 `little is known`。

强缺口包含：

```text
Existing work has explained X, but it leaves Y unclear. This matters because Z.
```

弱缺口通常只有：

```text
Few studies have examined Y.
```

## 4. Research Question Fit

- 5 分：RQ 精准覆盖研究对象、核心关系、机制、案例或分析边界。
- 3 分：RQ 能覆盖主题，但过宽或与后文 hypotheses / analysis 不完全对应。
- 1 分：RQ 像口号，无法指导研究设计。

检查问题：

- RQ 是否能自然导出 hypotheses、analysis 或 theoretical argument？
- RQ 是否和 method / data / case / materials 对应？
- RQ 是否避免问一个本文无法回答的大问题？

## 5. Key Element Integration

- 5 分：核心变量、机制、案例、方法、数据或理论情境不是突然出现，而是从问题链中自然生长出来。
- 3 分：关键元素相关，但引入略显机械。
- 1 分：关键元素像为了研究设计或文章结构硬加进去。

检查问题：

- 每个核心变量、机制或案例是否回答了前文留下的问题？
- 调节变量或边界条件是否解释了核心关系何时更强或更弱？
- 方法或数据是否自然服务于研究问题，而不是突然出现？
- 如果是理论论文，新概念或框架是否从既有理论张力中自然推出？

## 6. Contribution Alignment

- 5 分：结尾贡献与后文 Discussion / Conclusion 的理论对话高度一致，但不过度展开。
- 3 分：贡献相关，但太泛或与后文 discussion 语言不一致。
- 1 分：贡献只说 `fills a gap` 或 `enriches the literature`。

检查问题：

- 是否有明确贡献对象？
- 每个贡献是否说明从什么推进到什么，或解决了什么理论张力？
- 是否避免把贡献写成结果复述？
- 后文是否真正回到这些贡献？

## 7. Evidence And Citation Discipline

- 5 分：每个实质性文献判断都有直接支撑，且引用不堆砌。
- 3 分：大部分有支撑，但个别句子引用过泛。
- 1 分：重要判断没有文献支持，或文献只是装饰。

检查问题：

- 一个括号内是否通常不超过两篇文献？
- 引文是否紧贴它支持的判断？
- 是否避免把多个大判断塞进一个句子后面挂一串引用？

## 8. Paragraph Architecture

- 5 分：段落短而有功能，段落之间呈递进关系。
- 3 分：大体顺，但有段落过长或功能混杂。
- 1 分：一个段落承担太多功能，读者迷路。

检查问题：

- 是否每段只有一个主要功能？
- 段落首句是否告诉读者本段要推进什么？
- 是否在换主题、换文献线、换理论层级、换变量或换方法入口时另起一段？

## 9. English Academic Style

- 5 分：英语平实、清楚、自然，有目标期刊论文的克制感。
- 3 分：基本清楚，但有重复、模板化或中式表达。
- 1 分：表达拖沓、连接词机械、生造概念多。

高风险表达：

```text
under the background of
with the rapid development of
this paper fills the gap
has important theoretical and practical significance
from the perspective of
in the process of
```
