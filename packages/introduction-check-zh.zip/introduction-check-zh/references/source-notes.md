# Source Notes For Introduction Check

本文件记录本 skill 的写作依据。它是规则来源笔记，不是可复制的书摘。

## Wallwork 2023, English for Writing Research Papers

- Introduction 不是历史综述，而是在已有研究和本文贡献之间持续比较。
- 只引用关键文献不够，作者必须说明自己如何建立在这些文献之上，以及本文与已有研究的区别。
- Introduction 应限制在必要背景、研究动机、发现意义所需的信息内，不宜变成冗长历史。
- Introduction 和 Abstract 有重叠但功能不同，不能简单复制摘要句子。
- 段落应随着主题、阶段、作者观点、研究目的或文章结构变化而分开。
- 自检问题包括：引言是否过长、是否有太多常识背景、研究理据和目标是否明确、背景是否服务于目标、读者是否知道本文会贡献什么。

Relevant extracted locations: PDF pp. 233-247, especially sections 14.1, 14.2, 14.3, 14.8, 14.11.

## 范逸洲、童士敦、毛君等 2024, 英文学术写作实战

- 文献综述或引言不能和后文分析“两张皮”，要围绕研究问题组织文献。
- 好的综述要系统、批判地组织已有研究，而不是罗列成果。
- 常见逻辑模型包括 general-to-specific、old-to-new、problem-solution 和 process。Introduction 通常混合使用前几种。
- 问题陈述要从背景自然推出，并能够统领后文方法和发现。
- 连接词不是装饰，应该服务于逻辑关系；summary words 和适当重复可以帮助读者追踪论证。

Relevant extracted locations: PDF pp. 92-93, 117, 130-131, 276.

## Booth et al. 2024, The Craft of Research, fifth edition

- 研究问题必须从读者角度说明其重要性，而不只是作者自己感兴趣。
- 好的研究问题要能回答 `So what?`，让读者承认这里存在需要解决的概念问题或实践问题。
- 论证核心由 claim、reasons、evidence、warrants 和 responses to objections 构成。
- Claim 需要具体且重要。模糊 claim 会导致模糊论证。
- 作者应预判读者会质疑研究问题、论证逻辑、证据、替代解释和问题框定。
- 写作应从读者已有问题出发，逐步引导读者接受本文 claim 的必要性。

Relevant extracted locations: PDF pp. 61-64, 130, 150-153, 162, 198-200, 222, 341.

## Belcher 2015, 学术期刊论文写作必修课

当前 PDF 文本层不可稳定抽取，未记录页码式细节。skill 只吸收其期刊论文修订取向：Introduction 应面向目标期刊读者和审稿人，尽早建立文章论点、问题重要性和投稿领域的对话位置。

